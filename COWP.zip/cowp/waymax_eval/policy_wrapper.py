from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from cowp.core.constants import MacroType
from cowp.label.trajectory_primitives import constant_accel_trajectory, smooth_stop_trajectory, repair_planar_kinematics


def _load_state_dict_compatible(model, state: dict) -> None:
    """Load old checkpoints after adding optional heads."""
    try:
        model.load_state_dict(state)
        return
    except Exception:
        pass
    if state and all(str(k).startswith("_orig_mod.") for k in state.keys()):
        state = {k[len("_orig_mod."):]: v for k, v in state.items()}
        try:
            model.load_state_dict(state)
            return
        except Exception:
            pass
    model_state = model.state_dict()
    compatible = {k: v for k, v in state.items() if k in model_state and tuple(model_state[k].shape) == tuple(v.shape)}
    model.load_state_dict(compatible, strict=False)


def _to_numpy(x: Any) -> np.ndarray:
    try:
        import jax  # type: ignore

        x = jax.device_get(x)
    except Exception:
        pass
    try:
        return np.asarray(x)
    except Exception as exc:
        raise TypeError(f"Cannot convert object of type {type(x)!r} to numpy array") from exc


def _get_field(obj: Any, names: tuple[str, ...]) -> Any | None:
    for name in names:
        if obj is None:
            return None
        if hasattr(obj, name):
            return getattr(obj, name)
        if isinstance(obj, dict) and name in obj:
            return obj[name]
    return None


def _unwrap_batch_dim(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr)
    while arr.ndim > 2:
        arr = arr[0]
    return arr


def _wrap_angle(x: np.ndarray | float) -> np.ndarray | float:
    return (np.asarray(x) + np.pi) % (2.0 * np.pi) - np.pi


def _canonical_online_method(method: str | None, gate_mode: str | None = None) -> tuple[str, str]:
    """Normalize online method aliases before expensive policy branches run."""
    m = str(method or "cowp").lower()
    alias = {
        "cowp_priority": "cowp",
        "priority_ncf": "cowp",
        "p_ncf": "cowp",
        "cowp_universal": "universal_ncf",
        "hard_ncf": "universal_ncf",
        "ego_utility": "idm_lattice",
        "utility_lattice": "idm_lattice",
        "planner_only": "planner_score_only",
        "no_ncf": "planner_score_only",
        "safety_only": "conventional_safety",
    }
    m = alias.get(m, m)
    g = str(gate_mode or "priority").lower()
    if m == "cowp" and g == "hard":
        g = "priority"
    if m == "universal_ncf":
        g = "hard"
    elif m == "soft_burden_cost_only":
        g = "soft"
    elif m in {"idm_lattice", "conventional_safety", "planner_score_only"}:
        g = "none"
    return m, g


def _stable_logistic_np(x: np.ndarray | float) -> np.ndarray | float:
    x_arr = np.clip(np.asarray(x, dtype=np.float32), -50.0, 50.0)
    return 1.0 / (1.0 + np.exp(x_arr))


def _traj_arrays(state: Any) -> tuple[Any, int]:
    traj = _get_field(state, ("sim_trajectory", "trajectory", "log_trajectory"))
    timestep = _get_field(state, ("timestep", "time_index", "current_timestep"))
    t = int(_to_numpy(timestep).reshape(-1)[0]) if timestep is not None else 0
    if traj is None:
        raise ValueError("SimulatorState has no sim_trajectory/trajectory/log_trajectory attribute.")
    return traj, t


def _extract_sdc_index(state: Any, default: int = 0) -> int:
    is_sdc = _get_field(state, ("is_sdc", "sdc_mask"))
    if is_sdc is None:
        meta = _get_field(state, ("object_metadata", "metadata"))
        is_sdc = _get_field(meta, ("is_sdc",)) if meta is not None else None
    if is_sdc is not None:
        sdc_arr = _to_numpy(is_sdc)
        while sdc_arr.ndim > 1:
            sdc_arr = sdc_arr[0]
        if sdc_arr.size:
            return int(np.argmax(sdc_arr.astype(float)))
    return int(default)


def _extract_traj_components(state: Any) -> dict[str, np.ndarray]:
    traj, _ = _traj_arrays(state)
    x = _unwrap_batch_dim(_to_numpy(_get_field(traj, ("x", "center_x"))))
    y = _unwrap_batch_dim(_to_numpy(_get_field(traj, ("y", "center_y"))))
    yaw_field = _get_field(traj, ("yaw", "heading", "bbox_yaw"))
    vx_field = _get_field(traj, ("vel_x", "velocity_x", "vx"))
    vy_field = _get_field(traj, ("vel_y", "velocity_y", "vy"))
    length_field = _get_field(traj, ("length",))
    width_field = _get_field(traj, ("width",))
    height_field = _get_field(traj, ("height",))
    valid_field = _get_field(traj, ("valid",))
    zeros = np.zeros_like(x, dtype=np.float32)
    return {
        "x": x.astype(np.float32),
        "y": y.astype(np.float32),
        "yaw": _unwrap_batch_dim(_to_numpy(yaw_field)).astype(np.float32) if yaw_field is not None else zeros.copy(),
        "vx": _unwrap_batch_dim(_to_numpy(vx_field)).astype(np.float32) if vx_field is not None else zeros.copy(),
        "vy": _unwrap_batch_dim(_to_numpy(vy_field)).astype(np.float32) if vy_field is not None else zeros.copy(),
        "length": _unwrap_batch_dim(_to_numpy(length_field)).astype(np.float32) if length_field is not None else np.full_like(x, 4.8, dtype=np.float32),
        "width": _unwrap_batch_dim(_to_numpy(width_field)).astype(np.float32) if width_field is not None else np.full_like(x, 1.9, dtype=np.float32),
        "height": _unwrap_batch_dim(_to_numpy(height_field)).astype(np.float32) if height_field is not None else np.full_like(x, 1.6, dtype=np.float32),
        "valid": _unwrap_batch_dim(_to_numpy(valid_field)).astype(bool) if valid_field is not None else np.ones_like(x, dtype=bool),
    }


def _state11_at(components: dict[str, np.ndarray], t: int) -> np.ndarray:
    x = components["x"]
    if x.ndim == 2:
        tt = int(np.clip(t, 0, x.shape[1] - 1))
        cols = [components[k][:, tt] for k in ("x", "y", "yaw", "vx", "vy", "length", "width", "height", "valid")]
    else:
        cols = [components[k] for k in ("x", "y", "yaw", "vx", "vy", "length", "width", "height", "valid")]
    x_c, y_c, yaw_c, vx_c, vy_c, l_c, w_c, h_c, v_c = cols
    N = int(np.asarray(x_c).shape[0])
    out = np.zeros((N, 11), dtype=np.float32)
    out[:, 0] = np.nan_to_num(x_c, nan=0.0)
    out[:, 1] = np.nan_to_num(y_c, nan=0.0)
    out[:, 3] = np.nan_to_num(vx_c, nan=0.0)
    out[:, 4] = np.nan_to_num(vy_c, nan=0.0)
    out[:, 5] = np.linalg.norm(out[:, 3:5], axis=-1)
    out[:, 6] = np.nan_to_num(yaw_c, nan=0.0)
    out[:, 7] = np.where(np.asarray(l_c) > 0, l_c, 4.8)
    out[:, 8] = np.where(np.asarray(w_c) > 0, w_c, 1.9)
    out[:, 9] = np.where(np.asarray(h_c) > 0, h_c, 1.6)
    out[:, 10] = np.asarray(v_c).astype(bool).astype(np.float32)
    return out


def extract_current_agent_state(state: Any) -> tuple[np.ndarray, int]:
    """Best-effort extraction of [N,11] current states from a Waymax SimulatorState."""
    _, t = _traj_arrays(state)
    comps = _extract_traj_components(state)
    return _state11_at(comps, t), _extract_sdc_index(state)


def _extract_logged_future_agent_trajs(state: Any, sdc_index: int, cfg: dict) -> np.ndarray | None:
    """Best-effort logged/simulator future for online conventional checks."""
    try:
        _, t = _traj_arrays(state)
        comps = _extract_traj_components(state)
    except Exception:
        return None
    H = int(cfg.get("time", {}).get("future_steps", cfg.get("eval", {}).get("rollout_horizon_steps", 80)))
    cur = _state11_at(comps, t)
    N = int(cur.shape[0])
    out = np.zeros((N, H, 7), dtype=np.float32)
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    has_temporal = np.asarray(comps.get("x", np.zeros(0))).ndim == 2
    T = int(comps["x"].shape[1]) if has_temporal else 0
    for h in range(H):
        if has_temporal and t + 1 + h < T:
            s11 = _state11_at(comps, t + 1 + h)
        else:
            s11 = cur.copy()
            tau = float(h + 1) * dt
            s11[:, :2] = cur[:, :2] + cur[:, 3:5] * tau
        out[:, h, 0:2] = s11[:, 0:2]
        out[:, h, 2] = s11[:, 6]
        out[:, h, 3:5] = s11[:, 3:5]
        out[:, h, 5] = s11[:, 7]
        out[:, h, 6] = s11[:, 8]
    if 0 <= int(sdc_index) < N:
        out[int(sdc_index), :, :] = 0.0
    return out


def extract_agent_history_model_state(state: Any, cfg: dict) -> tuple[np.ndarray, np.ndarray, int]:
    """Extract model-format history and current ScenarioData-format states.

    Training cache uses [x,y,z,length,width,height,heading,vx,vy,speed,valid].
    The first online wrapper only supplied a single current frame, which made the
    encoder distribution much narrower than training.  This helper pads the last
    ``history_steps`` frames from Waymax, reusing the earliest available frame at
    the beginning of an episode.
    """
    _, t = _traj_arrays(state)
    comps = _extract_traj_components(state)
    cur11 = _state11_at(comps, t)
    sdc = _extract_sdc_index(state)
    hist_steps = int(cfg.get("model", cfg).get("history_steps", cfg.get("time", {}).get("history_steps", 11)))
    max_agents = int(cfg.get("limits", {}).get("max_agents", cfg.get("model", cfg).get("max_agents", 128)))
    d_state = int(cfg.get("model", cfg).get("d_state", 11))
    n = min(max_agents, cur11.shape[0])
    hist = np.zeros((max_agents, hist_steps, d_state), dtype=np.float32)
    if comps["x"].ndim == 2:
        indices = [int(np.clip(t - hist_steps + 1 + h, 0, comps["x"].shape[1] - 1)) for h in range(hist_steps)]
    else:
        indices = [t for _ in range(hist_steps)]
    for h, tt in enumerate(indices):
        s11 = _state11_at(comps, tt)[:n]
        hist[:n, h, 0:3] = s11[:, 0:3]
        hist[:n, h, 3:6] = s11[:, 7:10]
        hist[:n, h, 6] = s11[:, 6]
        hist[:n, h, 7:9] = s11[:, 3:5]
        hist[:n, h, 9] = s11[:, 5]
        hist[:n, h, 10] = s11[:, 10]
    mask = np.zeros(max_agents, dtype=bool)
    mask[:n] = cur11[:n, 10] > 0.5
    if 0 <= sdc < max_agents:
        mask[sdc] = True
    return hist, cur11, sdc


def _extract_roadgraph_tokens(state: Any, cfg: dict) -> dict[str, np.ndarray]:
    """Return best-effort roadgraph point tokens from Waymax state.

    Public/local Waymax builds expose roadgraph fields with slightly different
    names.  The policy should not fail if roadgraph is unavailable; it simply
    falls back to ego-heading proposals.
    """
    rg = _get_field(state, ("roadgraph_points", "roadgraph", "roadgraph_static_points"))
    if rg is None:
        return {"xy": np.zeros((0, 2), dtype=np.float32), "heading": np.zeros(0, dtype=np.float32), "valid": np.zeros(0, dtype=bool), "types": np.zeros(0, dtype=np.int32)}
    x_field = _get_field(rg, ("x", "center_x"))
    y_field = _get_field(rg, ("y", "center_y"))
    xy_field = _get_field(rg, ("xy", "points", "xyz"))
    if x_field is not None and y_field is not None:
        x = _to_numpy(x_field)
        y = _to_numpy(y_field)
        while x.ndim > 1:
            x = x[0]
            y = y[0]
        xy = np.stack([x, y], axis=-1).astype(np.float32)
    elif xy_field is not None:
        arr = _to_numpy(xy_field)
        while arr.ndim > 2:
            arr = arr[0]
        xy = arr[..., :2].reshape(-1, 2).astype(np.float32)
    else:
        return {"xy": np.zeros((0, 2), dtype=np.float32), "heading": np.zeros(0, dtype=np.float32), "valid": np.zeros(0, dtype=bool), "types": np.zeros(0, dtype=np.int32)}
    dir_x = _get_field(rg, ("dir_x", "direction_x", "dx"))
    dir_y = _get_field(rg, ("dir_y", "direction_y", "dy"))
    if dir_x is not None and dir_y is not None:
        dx = _to_numpy(dir_x)
        dy = _to_numpy(dir_y)
        while dx.ndim > 1:
            dx = dx[0]
            dy = dy[0]
        heading = np.arctan2(dy.reshape(-1), dx.reshape(-1)).astype(np.float32)
    else:
        # Local finite-difference heading.  It is noisy across polyline breaks but
        # still better than all-zero map tokens for conflict-query conditioning.
        diff = np.gradient(xy, axis=0) if len(xy) > 1 else np.zeros_like(xy)
        heading = np.arctan2(diff[:, 1], diff[:, 0]).astype(np.float32)
    valid_field = _get_field(rg, ("valid",))
    if valid_field is not None:
        valid = _to_numpy(valid_field)
        while valid.ndim > 1:
            valid = valid[0]
        valid = valid.reshape(-1).astype(bool)[: len(xy)]
    else:
        valid = np.isfinite(xy).all(axis=-1)
    type_field = _get_field(rg, ("types", "type", "map_element_type"))
    if type_field is not None:
        types = _to_numpy(type_field)
        while types.ndim > 1:
            types = types[0]
        types = types.reshape(-1).astype(np.int32)[: len(xy)]
    else:
        types = np.zeros(len(xy), dtype=np.int32)
    finite = np.isfinite(xy).all(axis=-1) & np.isfinite(heading)
    valid = valid & finite
    max_points = int(cfg.get("limits", {}).get("max_roadgraph_points", 20000))
    if len(xy) > max_points:
        # Keep a deterministic spread of points; local filtering below selects
        # only points near ego, so this mostly protects pathological states.
        idx = np.linspace(0, len(xy) - 1, max_points, dtype=np.int64)
        xy, heading, valid, types = xy[idx], heading[idx], valid[idx], types[idx]
    return {"xy": xy, "heading": heading, "valid": valid, "types": types}


def _lane_centerline_mask(roadgraph: dict[str, np.ndarray]) -> np.ndarray:
    """Waymax/WOMD lane centerline points only (exclude edges/crosswalks)."""
    valid = roadgraph.get("valid", np.zeros(0, dtype=bool)).astype(bool, copy=False)
    types = roadgraph.get("types", np.zeros(len(valid), dtype=np.int32))
    if len(types) != len(valid) or not np.any(types):
        return valid
    # WOMD RoadGraphSamples: 1 freeway, 2 surface street, 3 bike lane.
    # Vehicle planning intentionally excludes bike-lane centerlines.
    return valid & np.isin(types.astype(np.int32, copy=False), np.asarray([1, 2], dtype=np.int32))


def _nearest_lane_heading(current: np.ndarray, roadgraph: dict[str, np.ndarray], *, search_radius: float = 8.0) -> float:
    xy = roadgraph.get("xy", np.zeros((0, 2), dtype=np.float32))
    valid = _lane_centerline_mask(roadgraph)
    heading = roadgraph.get("heading", np.zeros(0, dtype=np.float32))
    if len(xy) == 0 or not np.any(valid):
        return float(current[6])
    d = np.linalg.norm(xy - current[:2][None], axis=-1)
    mask = valid & (d < float(search_radius))
    if not np.any(mask):
        return float(current[6])
    idx = np.where(mask)[0][np.argmin(d[mask])]
    h = float(heading[idx])
    # Prefer a lane direction aligned with the current vehicle heading.
    if np.cos(h - float(current[6])) < 0.0:
        h = float(_wrap_angle(h + np.pi))
    return h


def _quintic_frenet_trajectory(
    current: np.ndarray,
    horizon: int,
    dt: float,
    *,
    accel: float = 0.0,
    lateral_offset: float = 0.0,
    start_delay_s: float = 0.0,
    lane_change_duration_s: float = 4.0,
) -> np.ndarray:
    """Tangent-consistent Frenet primitive with quintic lateral motion.

    Unlike adding an offset to a longitudinal trajectory and repairing yaw later,
    this primitive derives position, velocity, and yaw from the same differentiable
    curve.  It therefore satisfies the StateDynamics action contract much more
    closely and avoids the dominant kinematic-infeasibility failure mode.
    """
    H = int(horizon)
    dt = float(dt)
    t = (np.arange(H, dtype=np.float32) + 1.0) * dt
    yaw0 = float(current[6])
    v0 = max(float(current[5]), float(np.linalg.norm(current[3:5])), 0.0)
    a = float(accel)
    v = np.maximum(v0 + a * t, 0.0)
    # Exact integral with a stop clamp; cumulative trapezoid is robust when v hits zero.
    v_prev = np.concatenate([np.asarray([v0], dtype=np.float32), v[:-1]])
    s_long = np.cumsum(0.5 * (v_prev + v) * dt).astype(np.float32)

    delay = max(float(start_delay_s), 0.0)
    duration = max(float(lane_change_duration_s), 1.5)
    u = np.clip((t - delay) / duration, 0.0, 1.0)
    q = 10.0 * u**3 - 15.0 * u**4 + 6.0 * u**5
    dq_du = 30.0 * u**2 - 60.0 * u**3 + 30.0 * u**4
    d_lat = float(lateral_offset) * q
    d_dot = float(lateral_offset) * dq_du / duration
    d_dot[(t <= delay) | (t >= delay + duration)] = 0.0

    e_s = np.asarray([np.cos(yaw0), np.sin(yaw0)], dtype=np.float32)
    e_d = np.asarray([-np.sin(yaw0), np.cos(yaw0)], dtype=np.float32)
    xy = current[:2][None, :] + s_long[:, None] * e_s[None, :] + d_lat[:, None] * e_d[None, :]
    vel = v[:, None] * e_s[None, :] + d_dot[:, None] * e_d[None, :]
    speed = np.linalg.norm(vel, axis=-1)
    yaw = np.where(speed > 0.15, np.arctan2(vel[:, 1], vel[:, 0]), yaw0).astype(np.float32)
    out = np.zeros((H, 7), dtype=np.float32)
    out[:, 0:2] = xy
    out[:, 2] = yaw
    out[:, 3:5] = vel
    out[:, 5] = float(current[7]) if current.shape[0] > 7 else 4.8
    out[:, 6] = float(current[8]) if current.shape[0] > 8 else 1.9
    return out


def _terminal_frenet_trajectory(
    current: np.ndarray,
    H: int,
    dt: float,
    *,
    target_s: float,
    target_speed: float,
    lateral_offset: float = 0.0,
    lane_change_duration_s: float = 4.0,
) -> np.ndarray:
    """Cubic-longitudinal / quintic-lateral terminal primitive."""
    T = max(float(H) * float(dt), float(dt))
    tau = (np.arange(1, H + 1, dtype=np.float32) * dt).astype(np.float32)
    v0 = float(max(current[5], np.linalg.norm(current[3:5]), 0.0))
    vT = float(max(target_speed, 0.0))
    sT = float(max(target_s, 0.0))
    A = np.asarray([[T**3, T**2], [3.0 * T**2, 2.0 * T]], dtype=np.float64)
    b = np.asarray([sT - v0 * T, vT - v0], dtype=np.float64)
    try:
        a3, a2 = np.linalg.solve(A, b)
    except np.linalg.LinAlgError:
        a3, a2 = 0.0, (vT - v0) / max(2.0 * T, 1e-3)
    s_long = (a3 * tau**3 + a2 * tau**2 + v0 * tau).astype(np.float32)
    v = np.maximum((3.0 * a3 * tau**2 + 2.0 * a2 * tau + v0).astype(np.float32), 0.0)
    yaw0 = float(current[6])
    e_s = np.asarray([np.cos(yaw0), np.sin(yaw0)], dtype=np.float32)
    e_d = np.asarray([-np.sin(yaw0), np.cos(yaw0)], dtype=np.float32)
    u = np.clip(tau / max(float(lane_change_duration_s), 1.5), 0.0, 1.0)
    q = 10.0 * u**3 - 15.0 * u**4 + 6.0 * u**5
    dq_du = 30.0 * u**2 - 60.0 * u**3 + 30.0 * u**4
    d_lat = float(lateral_offset) * q
    d_dot = float(lateral_offset) * dq_du / max(float(lane_change_duration_s), 1.5)
    vel = v[:, None] * e_s[None, :] + d_dot[:, None] * e_d[None, :]
    xy = current[:2][None, :] + s_long[:, None] * e_s[None, :] + d_lat[:, None] * e_d[None, :]
    speed = np.linalg.norm(vel, axis=-1)
    yaw = np.where(speed > 0.15, np.arctan2(vel[:, 1], vel[:, 0]), yaw0).astype(np.float32)
    out = np.zeros((H, 7), dtype=np.float32)
    out[:, 0:2] = xy
    out[:, 2] = yaw
    out[:, 3:5] = vel
    out[:, 5] = float(current[7]) if current.shape[0] > 7 else 4.8
    out[:, 6] = float(current[8]) if current.shape[0] > 8 else 1.9
    return out


def _candidate_dyn_ok(traj: np.ndarray, cfg: dict) -> bool:
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    cand_cfg = cfg.get("candidate", {})
    if traj.ndim != 2 or traj.shape[0] < 2 or traj.shape[1] < 5 or not np.all(np.isfinite(traj)):
        return False
    vel = traj[:, 3:5]
    speed = np.linalg.norm(vel, axis=-1)
    acc_vec = np.diff(vel, axis=0, prepend=vel[:1]) / max(dt, 1e-3)
    acc_long = np.diff(speed, prepend=speed[0]) / max(dt, 1e-3)
    jerk_vec = np.diff(acc_vec, axis=0, prepend=acc_vec[:1]) / max(dt, 1e-3)
    # A constant-acceleration primitive has a one-sample acceleration jump at the
    # beginning when acceleration is estimated from discrete velocities.  Counting
    # that initialization transient as jerk rejected nearly all yield/accelerate
    # online primitives, leaving only ~8 valid candidates and forcing frequent
    # fallback.  Ignore a small configurable prefix and evaluate the true steady
    # trajectory jerk.
    ignore = int(cand_cfg.get("ignore_initial_jerk_steps", cfg.get("planning", {}).get("online_ignore_initial_jerk_steps", 2)))
    jerk_eval = jerk_vec[min(max(ignore, 0), max(len(jerk_vec) - 1, 0)) :] if len(jerk_vec) else jerk_vec
    if jerk_eval.size == 0:
        jerk_eval = jerk_vec
    yaw = np.unwrap(traj[:, 2])
    yaw_rate = np.diff(yaw, prepend=yaw[0]) / max(dt, 1e-3)
    moving = speed > 0.5
    vel_heading = np.arctan2(vel[:, 1], vel[:, 0])
    slip = np.abs(_wrap_angle(vel_heading - traj[:, 2]))
    lateral_acc = np.abs(acc_vec[:, 0] * (-np.sin(traj[:, 2])) + acc_vec[:, 1] * np.cos(traj[:, 2]))
    jerk_norm = np.linalg.norm(jerk_eval, axis=-1) if jerk_eval.size else np.asarray([0.0], dtype=np.float32)
    jerk_stat = float(np.nanpercentile(jerk_norm, float(cand_cfg.get("jerk_check_percentile", 99.0))))
    return bool(
        np.nanmax(acc_long) <= float(cand_cfg.get("max_accel_mps2", 4.0)) + 1e-3
        and -np.nanmin(acc_long) <= float(cand_cfg.get("max_decel_mps2", 6.0)) + 1e-3
        and jerk_stat <= float(cand_cfg.get("max_jerk_mps3", 8.0)) + 1e-3
        and np.nanmax(np.abs(yaw_rate)) <= float(cand_cfg.get("max_yaw_rate_rad_s", 1.2)) + 1e-3
        and np.nanmax(lateral_acc) <= float(cand_cfg.get("max_lateral_accel_mps2", 4.0)) + 1e-3
        and (not np.any(moving) or np.nanmax(slip[moving]) <= float(cand_cfg.get("max_sideslip_rad", 0.20)))
    )


def _roadgraph_drivable_mask(traj: np.ndarray, roadgraph: dict[str, np.ndarray], max_dist: float = 5.5) -> bool:
    xy = roadgraph.get("xy", np.zeros((0, 2), dtype=np.float32))
    valid = _lane_centerline_mask(roadgraph)
    if len(xy) == 0 or not np.any(valid):
        return True
    sample = traj[np.linspace(0, len(traj) - 1, min(8, len(traj)), dtype=np.int64), :2]
    lo = np.nanmin(sample, axis=0) - float(max_dist) - 3.0
    hi = np.nanmax(sample, axis=0) + float(max_dist) + 3.0
    local = valid & (xy[:, 0] >= lo[0]) & (xy[:, 0] <= hi[0]) & (xy[:, 1] >= lo[1]) & (xy[:, 1] <= hi[1])
    if not np.any(local):
        d0 = np.linalg.norm(xy - sample[0][None, :], axis=-1)
        near = valid & (d0 < 60.0)
        pts = xy[near] if np.any(near) else xy[valid]
    else:
        pts = xy[local]
    if len(pts) > 2048:
        pts = pts[np.linspace(0, len(pts) - 1, 2048, dtype=np.int64)]
    d2 = ((sample[:, None, :] - pts[None, :, :]) ** 2).sum(axis=-1)
    return bool(np.mean(np.sqrt(np.min(d2, axis=1)) <= float(max_dist)) >= 0.75)

def _agent_future_xy(
    agent_state: np.ndarray,
    j: int,
    H: int,
    dt: float,
    other_future_trajs: np.ndarray | None,
) -> tuple[np.ndarray, np.ndarray]:
    ts = (np.arange(1, H + 1, dtype=np.float32)[:, None]) * max(float(dt), 1e-3)
    cv = agent_state[j, :2][None, :].astype(np.float32) + agent_state[j, 3:5][None, :].astype(np.float32) * ts
    logged = cv
    if other_future_trajs is not None and j < int(other_future_trajs.shape[0]) and other_future_trajs.shape[1] > 0:
        logged = np.asarray(other_future_trajs[j, :H, :2], dtype=np.float32)
        if logged.shape[0] < H:
            logged = np.concatenate([logged, cv[logged.shape[0]:]], axis=0)
        bad = ~np.isfinite(logged).all(axis=-1)
        if bad.any():
            logged[bad] = cv[bad]
    return logged, cv


def _collision_free_against_constant_velocity(
    traj: np.ndarray,
    agent_state: np.ndarray,
    sdc_index: int,
    cfg: dict,
    other_future_trajs: np.ndarray | None = None,
) -> bool:
    pcfg = cfg.get("planning", {})
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    H_full = int(len(traj))
    H = min(H_full, int(pcfg.get("online_collision_check_horizon_steps", H_full)))
    stride = max(1, int(pcfg.get("online_collision_check_stride", 2)))
    idx = np.arange(0, H, stride, dtype=np.int64)
    if idx.size == 0:
        idx = np.asarray([0], dtype=np.int64)
    traj_xy = np.asarray(traj[idx, :2], dtype=np.float32)
    if not np.isfinite(traj_xy).all():
        return False
    ego = agent_state[sdc_index]
    ego_radius = max(float(ego[7]), float(ego[8]), 4.0) * 0.5
    valid = agent_state[:, 10] > 0.5
    ego_xy = ego[:2].astype(np.float32)
    ego_yaw = float(ego[6])
    ego_dir = np.asarray([np.cos(ego_yaw), np.sin(ego_yaw)], dtype=np.float32)
    ego_lat = np.asarray([-ego_dir[1], ego_dir[0]], dtype=np.float32)
    ego_speed = max(float(ego[5]), float(np.linalg.norm(ego[3:5])))
    logged_buffer = float(pcfg.get("online_logged_collision_buffer_m", 0.10))
    cv_buffer = float(pcfg.get("online_priority_cv_collision_buffer_m", 0.35))
    require_cv = bool(pcfg.get("online_require_cv_for_priority_agents", True))
    max_dist = float(pcfg.get("online_collision_agent_radius_m", 60.0))
    max_agents = int(pcfg.get("online_collision_max_agents", 24))

    ranked: list[tuple[int, float, bool, float, float, float]] = []
    for j in range(agent_state.shape[0]):
        if j == sdc_index or not valid[j]:
            continue
        rel = agent_state[j, :2].astype(np.float32) - ego_xy
        dist = float(np.linalg.norm(rel))
        if dist > max_dist:
            continue
        longitudinal = float(np.dot(rel, ego_dir))
        lateral = abs(float(np.dot(rel, ego_lat)))
        rel_speed = float(max(0.0, ego_speed - np.dot(agent_state[j, 3:5], ego_dir)))
        ttc = longitudinal / max(rel_speed, 1e-3) if longitudinal > 0.0 and rel_speed > 0.25 else 99.0
        priority_like = (-8.0 <= longitudinal <= 55.0 and lateral <= 7.5) or (ttc <= float(pcfg.get("online_priority_ttc_s", 5.0)))
        # Check priority/front agents first, then nearest agents.  Limiting the
        # tail prevents pathological 128-agent scenes from dominating online COWP.
        rank = (0 if priority_like else 1, dist)
        ranked.append((j, float(rank[0]) * 1000.0 + rank[1], priority_like, longitudinal, lateral, ttc))
    ranked.sort(key=lambda x: x[1])
    if max_agents > 0:
        ranked = ranked[:max_agents]

    for j, _key, priority_like, _longitudinal, _lateral, _ttc in ranked:
        other_radius = max(float(agent_state[j, 7]), float(agent_state[j, 8]), 4.0) * 0.5
        radius = ego_radius + other_radius + 0.5
        logged, cv = _agent_future_xy(agent_state, j, H_full, dt, other_future_trajs)
        logged_xy = logged[idx]
        cv_xy = cv[idx]
        if not np.isfinite(logged_xy).all():
            logged_xy = cv_xy
        if not np.isfinite(logged_xy).all():
            continue
        min_logged = float(np.min(np.linalg.norm(traj_xy - logged_xy, axis=-1)))
        if min_logged < radius + logged_buffer:
            return False
        if require_cv and priority_like and np.isfinite(cv_xy).all():
            min_cv = float(np.min(np.linalg.norm(traj_xy - cv_xy, axis=-1)))
            if min_cv < radius + cv_buffer:
                return False
    return True

def _add_candidate(
    out: list[np.ndarray],
    macros: list[int],
    utils: list[float],
    valids: list[bool],
    traj: np.ndarray,
    macro: MacroType,
    utility: float,
    agent_state: np.ndarray,
    sdc_index: int,
    roadgraph: dict[str, np.ndarray],
    cfg: dict,
    conventional_check: bool = True,
    other_future_trajs: np.ndarray | None = None,
) -> None:
    if len(out) >= int(cfg.get("limits", {}).get("max_candidates", 64)):
        return
    traj = repair_planar_kinematics(traj, agent_state[sdc_index], float(cfg.get("time", {}).get("dt", 0.1)))
    if not _candidate_dyn_ok(traj, cfg):
        return
    # De-duplicate by endpoint to keep the limited candidate tensor useful.  The
    # original 0.35 m threshold removed most short-horizon smoke-test candidates
    # (especially low-speed accel/yield primitives), leaving the online planner
    # with too few alternatives and causing brittle fallback.
    end = traj[-1, :2]
    dedup_eps = float(cfg.get("planning", {}).get("online_candidate_dedup_endpoint_m", cfg.get("candidate", {}).get("dedup_endpoint_tolerance_m", 0.25)))
    dedup_eps = float(np.clip(dedup_eps, 0.05, 0.35))
    end_speed = float(np.linalg.norm(traj[-1, 3:5]))
    speed_eps = float(cfg.get("planning", {}).get("online_candidate_dedup_speed_mps", cfg.get("candidate", {}).get("dedup_speed_tolerance_mps", 0.15)))
    same_macro_only = bool(cfg.get("planning", {}).get("online_dedup_same_macro_only", True))
    for old_traj, old_macro in zip(out, macros):
        if same_macro_only and int(old_macro) != int(macro):
            continue
        old_speed = float(np.linalg.norm(old_traj[-1, 3:5]))
        if np.linalg.norm(old_traj[-1, :2] - end) < dedup_eps and abs(old_speed - end_speed) < speed_eps:
            return
    conv = True
    if conventional_check:
        conv = _roadgraph_drivable_mask(traj, roadgraph) and _collision_free_against_constant_velocity(
            traj, agent_state, sdc_index, cfg, other_future_trajs=other_future_trajs
        )
    out.append(traj.astype(np.float32))
    macros.append(int(macro))
    utils.append(float(utility))
    valids.append(bool(conv))


def _route_lane_aware_candidates(
    agent_state: np.ndarray,
    sdc_index: int,
    roadgraph: dict[str, np.ndarray],
    cfg: dict,
    *,
    other_future_trajs: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    limits = cfg.get("limits", {})
    K = int(limits.get("max_candidates", 64))
    H = int(cfg.get("time", {}).get("future_steps", cfg.get("eval", {}).get("rollout_horizon_steps", 80)))
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    current = agent_state[sdc_index].copy()
    current[6] = _nearest_lane_heading(current, roadgraph)
    speed = max(float(current[5]), 0.0)
    candidates: list[np.ndarray] = []
    macros: list[int] = []
    utils: list[float] = []
    conventional: list[bool] = []

    cand_cfg = cfg.get("candidate", {})
    acc_bank = [0.0]
    acc_bank.extend(float(x) for x in cand_cfg.get("yield_decel_values_mps2", [-1.0, -2.0, -3.0]))
    acc_bank.extend(float(x) for x in cand_cfg.get("accelerate_values_mps2", [0.5, 1.0, 1.5]))
    # Online closed-loop states are more diverse than the offline root cache.
    # Add a denser longitudinal bank so COWP can trade progress against safety
    # instead of being forced into fallback whenever the few root primitives fail.
    acc_bank.extend(float(x) for x in cfg.get("planning", {}).get("online_extra_accel_values_mps2", [-4.0, -2.5, -1.5, -0.5, 0.25, 0.75, 1.25, 2.0]))
    acc_bank = sorted(set(round(float(a), 3) for a in acc_bank))
    # Route/keep-lane timing lattice.
    for acc in acc_bank:
        macro = MacroType.KEEP_LANE if abs(acc) < 1e-6 else (MacroType.ACCELERATE_CROSS if acc > 0 else MacroType.YIELD)
        tr = constant_accel_trajectory(current, H, dt, accel=acc)
        progress = float(np.linalg.norm(tr[-1, :2] - tr[0, :2]))
        # Lower score is better. Prefer progress, penalize aggressive accel.
        util = -0.03 * progress + 0.08 * abs(acc)
        _add_candidate(candidates, macros, utils, conventional, tr, macro, util, agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs)

    # Stop / yield before likely conflicts.  In online mode we do not have proto
    # conflict regions, so estimate conflict distance from nearest forward agent
    # or route distance.
    ego_xy = current[:2]
    dir_vec = np.array([np.cos(current[6]), np.sin(current[6])], dtype=np.float32)
    rel = agent_state[:, :2] - ego_xy[None]
    along = rel @ dir_vec
    lateral = np.abs(rel @ np.array([-dir_vec[1], dir_vec[0]], dtype=np.float32))
    valid_other = (agent_state[:, 10] > 0.5)
    valid_other[sdc_index] = False
    forward = valid_other & (along > 3.0) & (along < 60.0) & (lateral < 8.0)
    conflict_dists = [float(x) for x in along[forward][:4]] if np.any(forward) else [max(12.0, speed * 2.5), max(22.0, speed * 4.0)]
    for dist in sorted(conflict_dists)[:4]:
        for margin in cand_cfg.get("stop_margin_to_conflict_m", [2.0, 5.0, 8.0]):
            tr = smooth_stop_trajectory(current, H, dt, decel=-2.0, stop_after_m=max(0.0, float(dist) - float(margin)))
            _add_candidate(candidates, macros, utils, conventional, tr, MacroType.STOP_BEFORE_CONFLICT, 0.4 + 0.02 * max(0.0, 20.0 - dist), agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs)

    # Merge-ahead/behind timing around nearby agents: vary speed to pass before or
    # after their projected conflict time.  This is still primitive-based, but it
    # creates the same root aggressive-vs-yield contrast as the label lattice.
    if np.any(valid_other):
        near_order = np.argsort(np.linalg.norm(agent_state[:, :2] - ego_xy[None], axis=-1))
        for j in near_order[: min(8, len(near_order))]:
            if j == sdc_index or not valid_other[j]:
                continue
            rel_j = agent_state[j, :2] - ego_xy
            s = float(rel_j @ dir_vec)
            if -10.0 <= s <= 55.0:
                for offset in cand_cfg.get("merge_time_offsets_s", [-1.2, -0.4, 0.4, 1.2]):
                    acc = float(np.clip(-0.9 * float(offset), -3.0, 2.0))
                    tr = constant_accel_trajectory(current, H, dt, accel=acc)
                    m = MacroType.MERGE_AHEAD if offset <= 0 else MacroType.MERGE_BEHIND
                    _add_candidate(candidates, macros, utils, conventional, tr, m, 0.05 + max(0.0, offset), agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs)

    # Lane-change/cut-in proposals.  Use ±lane_width relative to the local lane
    # heading; the conventional mask filters obvious offroad/collision cases.
    lane_widths = cfg.get("planning", {}).get("online_lane_change_offsets_m", [-3.5, 3.5])
    for lateral_offset in lane_widths:
        macro = MacroType.LANE_CHANGE_LEFT if lateral_offset > 0 else MacroType.LANE_CHANGE_RIGHT
        for delay in cand_cfg.get("lane_change_start_delay_s", [0.0, 0.5, 1.0, 1.5, 2.0]):
            for acc in [0.0, -0.5, 0.5]:
                tr = _quintic_frenet_trajectory(
                    current, H, dt, accel=acc, lateral_offset=float(lateral_offset),
                    start_delay_s=float(delay),
                    lane_change_duration_s=float(cfg.get("planning", {}).get("online_lane_change_duration_s", 4.0)),
                )
                progress = float(np.linalg.norm(tr[-1, :2] - tr[0, :2]))
                _add_candidate(candidates, macros, utils, conventional, tr, macro, -0.02 * progress + 0.15 + 0.03 * float(delay), agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs)

    # Terminal position-speed frontier fill.  This exposes distinct progress/yield
    # alternatives after closed-loop states have drifted away from the root cache.
    target_online = int(cfg.get("planning", {}).get("target_online_candidates", min(32, K)))
    if len(candidates) < min(target_online, K):
        speed_offsets = [float(x) for x in cfg.get("planning", {}).get(
            "online_terminal_speed_offsets_mps", [-5.0, -3.0, -1.5, 0.0, 1.5, 3.0]
        )]
        s_offsets = [float(x) for x in cfg.get("planning", {}).get(
            "online_terminal_s_offsets_m", [-16.0, -8.0, 0.0, 8.0, 16.0]
        )]
        lat_offsets = [0.0] + [float(x) for x in cfg.get("planning", {}).get("online_terminal_lateral_offsets_m", [])]
        nominal_s = max(float(speed) * float(H) * float(dt), 4.0)
        for lat in lat_offsets:
            for ds in s_offsets:
                for dv in speed_offsets:
                    if len(candidates) >= min(target_online, K) or len(candidates) >= K:
                        break
                    target_speed = max(0.0, speed + dv)
                    target_s = max(1.0, nominal_s + ds)
                    tr = _terminal_frenet_trajectory(
                        current, H, dt, target_s=target_s, target_speed=target_speed,
                        lateral_offset=float(lat),
                        lane_change_duration_s=float(cfg.get("planning", {}).get("online_lane_change_duration_s", 4.0)),
                    )
                    if abs(lat) > 1.0:
                        macro = MacroType.LANE_CHANGE_LEFT if lat > 0 else MacroType.LANE_CHANGE_RIGHT
                    elif target_speed > speed + 0.75 or target_s > nominal_s + 4.0:
                        macro = MacroType.ACCELERATE_CROSS
                    elif target_speed < max(speed - 0.75, 0.0) or target_s < nominal_s - 4.0:
                        macro = MacroType.YIELD
                    else:
                        macro = MacroType.KEEP_LANE
                    util = -0.025 * float(target_s) + 0.08 * abs(float(dv)) + 0.10 * abs(float(lat))
                    _add_candidate(
                        candidates, macros, utils, conventional, tr, macro, util,
                        agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs
                    )

    # Ensure the online batch contains a minimally useful ego-motion set even in
    # low-speed scenes where endpoint de-duplication and dynamics checks collapse
    # many primitives.  These are still kinematically repaired and checked first;
    # only the final neutral fallback bypasses the conservative mask.
    min_online = int(cfg.get("planning", {}).get("min_online_candidates", min(8, K)))
    if len(candidates) < min_online:
        supplemental_acc = [0.25, -0.25, 0.75, -0.75, 1.25, -1.25]
        for acc in supplemental_acc:
            if len(candidates) >= min_online or len(candidates) >= K:
                break
            macro = MacroType.ACCELERATE_CROSS if acc > 0 else MacroType.YIELD
            tr = constant_accel_trajectory(current, H, dt, accel=float(acc))
            progress = float(np.linalg.norm(tr[-1, :2] - tr[0, :2]))
            _add_candidate(candidates, macros, utils, conventional, tr, macro, -0.02 * progress + 0.10 * abs(acc), agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs)

    # Guaranteed conservative option, even if marked not conventional-safe.
    if len(candidates) < K:
        tr = smooth_stop_trajectory(current, H, dt, decel=float(cfg.get("planning", {}).get("fallback_decel_mps2", -2.0)))
        _add_candidate(candidates, macros, utils, conventional, tr, MacroType.NEUTRAL_EGO, 0.8, agent_state, sdc_index, roadgraph, cfg, conventional_check=False, other_future_trajs=other_future_trajs)

    traj = np.zeros((K, H, 7), dtype=np.float32)
    valid = np.zeros(K, dtype=bool)
    conventional_safe = np.zeros(K, dtype=bool)
    macro = np.full(K, int(MacroType.PAD), dtype=np.int64)
    utility = np.zeros(K, dtype=np.float32)
    for i, tr in enumerate(candidates[:K]):
        traj[i] = tr
        valid[i] = True
        conventional_safe[i] = bool(conventional[i])
        macro[i] = int(macros[i])
        utility[i] = float(utils[i])
    return traj, valid, conventional_safe, macro, utility


def _critical_interaction_rank(agent_state: np.ndarray, sdc_index: int, candidates: np.ndarray, cand_valid: np.ndarray, cfg: dict) -> tuple[np.ndarray, np.ndarray]:
    """Select a small, risk-focused critical-agent set.

    The original online builder filled almost every available slot, including
    weakly related agents.  That creates a severe train/online distribution shift
    and lets the max-over-agents witness gate reject nearly every candidate.
    """
    A = int(cfg.get("limits", {}).get("max_critical_agents", 8))
    plan_cfg = cfg.get("planning", {})
    active_cap = min(A, int(plan_cfg.get("max_online_critical_agents", 4)))
    min_score = float(plan_cfg.get("online_critical_score_threshold", 1.20))
    max_now = float(plan_cfg.get("online_critical_max_distance_m", 55.0))
    max_closest = float(plan_cfg.get("online_critical_max_closest_m", 18.0))
    valid_agents = agent_state[:, 10] > 0.5
    ego_xy = agent_state[sdc_index, :2]
    dist_now = np.linalg.norm(agent_state[:, :2] - ego_xy[None], axis=-1)
    scores = np.full(agent_state.shape[0], -1e9, dtype=np.float32)
    closest = np.full(agent_state.shape[0], np.inf, dtype=np.float32)
    cand_xy = candidates[cand_valid, :, :2] if np.any(cand_valid) else candidates[:1, :, :2]
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    t = np.arange(1, cand_xy.shape[1] + 1, dtype=np.float32)[None, :, None] * dt
    ego_vel = agent_state[sdc_index, 3:5]
    for j in range(agent_state.shape[0]):
        if j == sdc_index or not valid_agents[j] or dist_now[j] > max_now:
            continue
        pred = agent_state[j, :2][None, None, :] + agent_state[j, 3:5][None, None, :] * t
        min_dist = float(np.min(np.linalg.norm(cand_xy - pred, axis=-1))) if cand_xy.size else float(dist_now[j])
        closest[j] = min_dist
        rel = agent_state[j, :2] - ego_xy
        closing = -float(np.dot(rel, agent_state[j, 3:5] - ego_vel)) / max(float(np.linalg.norm(rel)), 1e-3)
        time_risk = np.exp(-max(0.0, min_dist) / 8.0)
        proximity = np.exp(-float(dist_now[j]) / 22.0)
        closing_bonus = 0.75 if closing > 1.0 else (0.35 if closing > 0.25 else 0.0)
        scores[j] = 3.5 * time_risk + 2.0 * proximity + closing_bonus
    order = [
        i for i in np.argsort(-scores).tolist()
        if i != sdc_index and valid_agents[i] and scores[i] >= min_score and closest[i] <= max_closest
    ]
    idx = np.full(A, 0, dtype=np.int64)
    mask = np.zeros(A, dtype=bool)
    for a, j in enumerate(order[:active_cap]):
        idx[a] = int(j)
        mask[a] = True
    return idx, mask


def _online_conflict_tokens(agent_state: np.ndarray, sdc_index: int, candidates: np.ndarray, cand_valid: np.ndarray, critical_idx: np.ndarray, critical_valid: np.ndarray, roadgraph: dict[str, np.ndarray], cfg: dict) -> tuple[np.ndarray, np.ndarray]:
    C = int(cfg.get("limits", {}).get("max_conflict_regions", 64))
    plan_cfg = cfg.get("planning", {})
    pair_cap = min(C, int(plan_cfg.get("max_online_pair_conflict_tokens", 24)))
    map_cap = min(max(C - pair_cap, 0), int(plan_cfg.get("max_online_map_tokens", 12)))
    tokens = np.zeros((C, 8), dtype=np.float32)
    valid = np.zeros(C, dtype=bool)
    rows: list[np.ndarray] = []
    ego = agent_state[sdc_index]
    active = candidates[cand_valid] if np.any(cand_valid) else candidates[:1]
    # Preserve macro/candidate diversity but avoid filling all 64 tokens with
    # near-duplicates.  Rank candidate-agent closest approaches globally.
    proposals: list[tuple[float, np.ndarray]] = []
    for a, j in enumerate(critical_idx):
        if not bool(critical_valid[a]):
            continue
        j = int(j)
        t = np.arange(1, active.shape[1] + 1, dtype=np.float32)[:, None] * float(cfg.get("time", {}).get("dt", 0.1))
        pred = agent_state[j, :2][None, :] + agent_state[j, 3:5][None, :] * t
        stride = max(1, len(active) // max(1, pair_cap // max(1, int(critical_valid.sum()))))
        for tr in active[::stride]:
            d = np.linalg.norm(tr[:, :2] - pred, axis=-1)
            m = int(np.argmin(d))
            center = 0.5 * (tr[m, :2] + pred[m])
            radius = max(4.0, 0.5 * (float(ego[7]) + float(agent_state[j, 7])) + 1.0)
            row = np.asarray([1.0, center[0], center[1], radius, float(d[m]), m / max(len(tr) - 1, 1), float(a), 1.0], dtype=np.float32)
            proposals.append((float(d[m]), row))
    for _, row in sorted(proposals, key=lambda x: x[0])[:pair_cap]:
        rows.append(row)

    xy = roadgraph.get("xy", np.zeros((0, 2), dtype=np.float32))
    lane_valid = _lane_centerline_mask(roadgraph)
    if len(xy) and np.any(lane_valid) and map_cap > 0:
        d = np.linalg.norm(xy - ego[:2][None], axis=-1)
        order = np.argsort(d)
        last_xy = None
        added = 0
        min_spacing = float(plan_cfg.get("online_map_token_spacing_m", 6.0))
        for q in order:
            if added >= map_cap or len(rows) >= C:
                break
            if not lane_valid[q] or d[q] > 60.0:
                continue
            if last_xy is not None and np.linalg.norm(xy[q] - last_xy) < min_spacing:
                continue
            rows.append(np.asarray([2.0, xy[q, 0], xy[q, 1], 4.0, d[q], 0.0, 0.0, 1.0], dtype=np.float32))
            last_xy = xy[q]
            added += 1
    for i, row in enumerate(rows[:C]):
        tokens[i] = np.nan_to_num(row, nan=0.0, posinf=0.0, neginf=0.0)
        valid[i] = True
    return tokens, valid



def _priority_claim_weights(
    agent_state: np.ndarray,
    sdc_index: int,
    candidates: np.ndarray,
    cand_valid: np.ndarray,
    critical_idx: np.ndarray,
    critical_valid: np.ndarray,
    macro: np.ndarray,
    cfg: dict,
) -> np.ndarray:
    """Heuristic right-of-way / priority proxy for online P-NCF gating.

    It is intentionally conservative: nearby same-direction lead/adjacent agents
    and agents whose constant-velocity path is close to an ego candidate receive
    higher priority.  The witness gate is hard only for high-priority claims;
    lower-priority conflicts become a soft ranking penalty.
    """
    K = int(candidates.shape[0])
    A = int(critical_idx.shape[0])
    out = np.zeros((K, A), dtype=np.float32)
    if not (0 <= sdc_index < agent_state.shape[0]):
        return out
    ego = agent_state[sdc_index]
    ego_xy = ego[:2].astype(np.float32)
    ego_yaw = float(ego[6])
    ego_dir = np.asarray([np.cos(ego_yaw), np.sin(ego_yaw)], dtype=np.float32)
    ego_lat = np.asarray([-np.sin(ego_yaw), np.cos(ego_yaw)], dtype=np.float32)
    ego_speed = float(max(ego[5], np.linalg.norm(ego[3:5])))
    H = candidates.shape[1] if candidates.ndim >= 3 else int(cfg.get("time", {}).get("future_steps", 80))
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    ts = (np.arange(H, dtype=np.float32) + 1.0)[:, None] * dt
    lane_change_macros = {
        int(MacroType.LANE_CHANGE_LEFT),
        int(MacroType.LANE_CHANGE_RIGHT),
        int(MacroType.MERGE_AHEAD),
        int(MacroType.ACCELERATE_CROSS),
    }
    macro_is_interactive = np.isin(macro.astype(np.int64, copy=False), list(lane_change_macros))
    for a, raw_j in enumerate(critical_idx):
        if not bool(critical_valid[a]):
            continue
        j = int(raw_j)
        if j < 0 or j >= agent_state.shape[0] or j == sdc_index:
            continue
        aj = agent_state[j]
        if aj.shape[0] < 11 or aj[10] <= 0.5:
            continue
        rel = aj[:2].astype(np.float32) - ego_xy
        longitudinal = float(np.dot(rel, ego_dir))
        lateral = abs(float(np.dot(rel, ego_lat)))
        dist = float(np.linalg.norm(rel))
        same_dir = float(np.cos(float(aj[6]) - ego_yaw)) > 0.4
        rel_speed_long = ego_speed - float(np.dot(aj[3:5], ego_dir))
        ttc = 99.0
        if longitudinal > 0.0 and rel_speed_long > 0.25:
            ttc = longitudinal / rel_speed_long
        base = 0.10
        base += 0.35 if (-6.0 <= longitudinal <= 45.0 and lateral <= 5.0 and same_dir) else 0.0
        base += 0.20 if dist <= 25.0 else 0.0
        base += 0.20 if ttc <= 5.0 else 0.0
        agent_pred = aj[:2][None, :] + aj[3:5][None, :] * ts
        for k in range(K):
            if not bool(cand_valid[k]):
                continue
            cand_xy = candidates[k, :, :2]
            finite = np.isfinite(cand_xy).all(axis=-1)
            if not finite.any():
                continue
            min_d = float(np.min(np.linalg.norm(cand_xy[finite] - agent_pred[finite], axis=-1)))
            risk = float(np.exp(-max(min_d, 0.0) / 9.0))
            w = base + 0.35 * risk + (0.10 if bool(macro_is_interactive[k]) else 0.0)
            out[k, a] = np.float32(np.clip(w, 0.0, 1.0))
    return out

def _candidate_pressure_prior_np(
    agent_state: np.ndarray,
    sdc_index: int,
    candidates: np.ndarray,
    cand_valid: np.ndarray,
    critical_idx: np.ndarray,
    critical_valid: np.ndarray,
    macro: np.ndarray,
    cfg: dict,
    other_future_trajs: np.ndarray | None = None,
) -> np.ndarray:
    """Mechanism-aware coercion pressure prior for online P-NCF selection.

    Vectorized over candidates.  The previous K x A Python loop was not the main
    theory issue, but it made COWP Waymax rollout too slow for diagnosis.
    """
    K = int(candidates.shape[0])
    out = np.zeros(K, dtype=np.float32)
    if K == 0 or not (0 <= int(sdc_index) < int(agent_state.shape[0])):
        return out
    pcfg = cfg.get("planning", {})
    H_full = int(candidates.shape[1]) if candidates.ndim >= 3 else int(cfg.get("time", {}).get("future_steps", 80))
    H = min(H_full, int(pcfg.get("online_pressure_prior_horizon_steps", H_full)))
    stride = max(1, int(pcfg.get("online_pressure_prior_stride", pcfg.get("online_rule_risk_stride", 2))))
    idx = np.arange(0, H, stride, dtype=np.int64)
    if idx.size == 0:
        idx = np.asarray([0], dtype=np.int64)
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    cand_xy = np.asarray(candidates[:, idx, :2], dtype=np.float32)
    finite_k = cand_valid.astype(bool) & np.isfinite(cand_xy).all(axis=(1, 2))
    pressure_macros = {
        int(MacroType.ACCELERATE_CROSS): 0.75,
        int(MacroType.MERGE_AHEAD): 0.90,
        int(MacroType.LANE_CHANGE_LEFT): 0.70,
        int(MacroType.LANE_CHANGE_RIGHT): 0.70,
    }
    relief_macros = {
        int(MacroType.YIELD): -0.25,
        int(MacroType.STOP_BEFORE_CONFLICT): -0.35,
        int(MacroType.NEUTRAL_EGO): -0.20,
        int(MacroType.CREEP): -0.10,
        int(MacroType.MERGE_BEHIND): -0.15,
    }
    macro_bias = np.zeros(K, dtype=np.float32)
    for k in range(K):
        mk = int(macro[k]) if k < len(macro) else int(MacroType.KEEP_LANE)
        macro_bias[k] = float(pressure_macros.get(mk, 0.05) + relief_macros.get(mk, 0.0))
    worst = np.maximum(macro_bias, 0.0).astype(np.float32)
    ego = agent_state[int(sdc_index)]
    ego_xy = ego[:2].astype(np.float32)
    ego_yaw = float(ego[6])
    ego_dir = np.asarray([np.cos(ego_yaw), np.sin(ego_yaw)], dtype=np.float32)
    ego_lat = np.asarray([-np.sin(ego_yaw), np.cos(ego_yaw)], dtype=np.float32)
    ego_speed = float(max(ego[5], np.linalg.norm(ego[3:5]), 0.0))
    max_agents = int(pcfg.get("online_pressure_prior_max_agents", 8))
    active: list[tuple[int, float]] = []
    for a, raw_j in enumerate(critical_idx):
        if not bool(critical_valid[a]):
            continue
        j = int(raw_j)
        if j < 0 or j >= agent_state.shape[0] or j == sdc_index or agent_state[j, 10] <= 0.5:
            continue
        active.append((j, float(np.linalg.norm(agent_state[j, :2].astype(np.float32) - ego_xy))))
    active.sort(key=lambda x: x[1])
    if max_agents > 0:
        active = active[:max_agents]
    for j, _dist in active:
        aj = agent_state[j]
        pred, _cv = _agent_future_xy(agent_state, j, H_full, dt, other_future_trajs)
        pred = np.asarray(pred[idx, :2], dtype=np.float32)
        tmask = np.isfinite(pred).all(axis=-1)
        if not bool(tmask.any()):
            continue
        d = np.full(K, 99.0, dtype=np.float32)
        diff = cand_xy[:, tmask, :] - pred[None, tmask, :]
        d[finite_k] = np.sqrt(np.min(np.sum(diff[finite_k] * diff[finite_k], axis=-1), axis=-1))
        close = np.exp(-np.maximum(d, 0.0) / 6.5)
        rel = aj[:2].astype(np.float32) - ego_xy
        longitudinal = float(np.dot(rel, ego_dir))
        lateral = abs(float(np.dot(rel, ego_lat)))
        rel_speed = ego_speed - float(np.dot(aj[3:5], ego_dir))
        ttc = longitudinal / max(rel_speed, 1e-3) if longitudinal > 0.0 and rel_speed > 0.25 else 99.0
        priority = 0.0
        priority += 0.35 if -6.0 <= longitudinal <= 45.0 and lateral <= 5.5 else 0.0
        priority += 0.25 if ttc <= 5.0 else 0.0
        priority += 0.20 if (bool(finite_k.any()) and float(np.min(d[finite_k])) <= 6.0) else 0.0
        worst = np.maximum(worst, macro_bias + 0.55 * close.astype(np.float32) + float(priority))
    out[finite_k] = np.clip(worst[finite_k], 0.0, 1.0)
    return out



def _candidate_rule_risk_np(
    agent_state: np.ndarray,
    sdc_index: int,
    candidates: np.ndarray,
    cand_valid: np.ndarray,
    conventional_safe: np.ndarray,
    critical_idx: np.ndarray,
    critical_valid: np.ndarray,
    cfg: dict,
    other_future_trajs: np.ndarray | None = None,
) -> np.ndarray:
    """Fast counterfactual rule risk for online candidate selection.

    This is intentionally low-capacity: it should calibrate obvious logged-future
    false-safety without becoming a hand-coded closed-loop planner.  The
    implementation is vectorized over candidates and clips the sigmoid argument
    to avoid log-spam from exp overflow.
    """
    K = int(candidates.shape[0])
    out = np.ones(K, dtype=np.float32)
    if K == 0 or not (0 <= int(sdc_index) < int(agent_state.shape[0])):
        return out
    pcfg = cfg.get("planning", {})
    H_full = int(candidates.shape[1]) if candidates.ndim >= 3 else int(cfg.get("time", {}).get("future_steps", 80))
    H = min(H_full, int(pcfg.get("online_rule_risk_horizon_steps", pcfg.get("online_collision_check_horizon_steps", H_full))))
    stride = max(1, int(pcfg.get("online_rule_risk_stride", pcfg.get("online_collision_check_stride", 2))))
    idx = np.arange(0, H, stride, dtype=np.int64)
    if idx.size == 0:
        idx = np.asarray([0], dtype=np.int64)
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    ego = agent_state[int(sdc_index)]
    ego_radius = max(float(ego[7]), float(ego[8]), 4.0) * 0.5
    ego_xy = ego[:2].astype(np.float32)
    ego_yaw = float(ego[6])
    ego_dir = np.asarray([np.cos(ego_yaw), np.sin(ego_yaw)], dtype=np.float32)
    ego_lat = np.asarray([-ego_dir[1], ego_dir[0]], dtype=np.float32)
    ego_speed = float(max(ego[5], np.linalg.norm(ego[3:5]), 0.0))
    valid_agents = agent_state[:, 10] > 0.5
    active_agents: list[tuple[int, float]] = []
    for raw_j, ok in zip(critical_idx, critical_valid):
        if not bool(ok):
            continue
        j = int(raw_j)
        if j != sdc_index and 0 <= j < agent_state.shape[0] and bool(valid_agents[j]):
            active_agents.append((j, float(np.linalg.norm(agent_state[j, :2].astype(np.float32) - ego_xy))))
    if not active_agents:
        near = np.argsort(np.linalg.norm(agent_state[:, :2] - ego_xy[None, :], axis=-1))[:8]
        active_agents = [(int(j), float(np.linalg.norm(agent_state[int(j), :2] - ego_xy))) for j in near if int(j) != int(sdc_index) and bool(valid_agents[int(j)])]
    active_agents.sort(key=lambda x: x[1])
    max_agents = int(pcfg.get("online_rule_risk_max_agents", 8))
    if max_agents > 0:
        active_agents = active_agents[:max_agents]

    cand_xy = np.asarray(candidates[:, idx, :2], dtype=np.float32)
    finite_k = cand_valid.astype(bool) & np.isfinite(cand_xy).all(axis=(1, 2))
    worst = np.where(conventional_safe.astype(bool), 0.0, 0.25).astype(np.float32)
    for j, dist0 in active_agents:
        if dist0 > float(pcfg.get("online_rule_risk_agent_radius_m", 60.0)):
            continue
        aj = agent_state[j]
        rel = aj[:2].astype(np.float32) - ego_xy
        other_radius = max(float(aj[7]), float(aj[8]), 4.0) * 0.5
        radius = ego_radius + other_radius + 0.5
        logged, cv = _agent_future_xy(agent_state, j, H_full, dt, other_future_trajs)
        logged_xy = np.asarray(logged[idx, :2], dtype=np.float32)
        cv_xy = np.asarray(cv[idx, :2], dtype=np.float32)
        logged_mask = np.isfinite(logged_xy).all(axis=-1)
        cv_mask = np.isfinite(cv_xy).all(axis=-1)
        d_logged = np.full(K, 99.0, dtype=np.float32)
        d_cv = np.full(K, 99.0, dtype=np.float32)
        if bool(logged_mask.any()):
            diff = cand_xy[:, logged_mask, :] - logged_xy[None, logged_mask, :]
            d_logged[finite_k] = np.sqrt(np.min(np.sum(diff[finite_k] * diff[finite_k], axis=-1), axis=-1))
        if bool(cv_mask.any()):
            diff = cand_xy[:, cv_mask, :] - cv_xy[None, cv_mask, :]
            d_cv[finite_k] = np.sqrt(np.min(np.sum(diff[finite_k] * diff[finite_k], axis=-1), axis=-1))
        longitudinal = float(np.dot(rel, ego_dir))
        lateral = abs(float(np.dot(rel, ego_lat)))
        rel_speed = ego_speed - float(np.dot(aj[3:5], ego_dir))
        ttc = longitudinal / max(rel_speed, 1e-3) if longitudinal > 0.0 and rel_speed > 0.25 else 99.0
        priority = 1.0 if (-8.0 <= longitudinal <= 55.0 and lateral <= 7.5) or ttc <= 5.0 else 0.0
        clearance = np.minimum(d_logged, d_cv if priority > 0.0 else np.maximum(d_cv, d_logged)) - float(radius)
        close_risk = _stable_logistic_np((clearance - 1.0) / 1.5).astype(np.float32)
        false_safe_risk = np.minimum(1.0, np.maximum(0.0, d_logged - d_cv) / 8.0).astype(np.float32) * float(priority)
        worst = np.maximum(worst, 0.70 * close_risk + 0.30 * false_safe_risk)
    out[finite_k] = np.clip(worst[finite_k], 0.0, 1.0)
    return out



def _one_step_action_risk_np(
    agent_state: np.ndarray,
    sdc_index: int,
    candidates: np.ndarray,
    cand_valid: np.ndarray,
    cfg: dict,
    previous_longitudinal_accel: float = 0.0,
) -> np.ndarray:
    """Kinematic-action risk used by the online frontier.

    The previous version only inspected the first commanded waypoint.  Waymax
    kinematic infeasibility can also be triggered by short-horizon acceleration,
    yaw-rate, or jerk spikes after the first step.  This diagnostic therefore
    scores the first few waypoints and uses the maximum violation as a
    hard-to-game selection penalty while still returning a compact [K] risk.
    """
    K = int(candidates.shape[0])
    out = np.zeros(K, dtype=np.float32)
    if not (0 <= int(sdc_index) < int(agent_state.shape[0])):
        return out
    dt = max(float(cfg.get("time", {}).get("dt", 0.1)), 1e-3)
    cand_cfg = cfg.get("candidate", {})
    pcfg = cfg.get("planning", {})
    cur = agent_state[int(sdc_index)]
    cur_speed = float(max(np.linalg.norm(cur[3:5]), cur[5] if cur.shape[0] > 5 else 0.0, 0.0))
    cur_yaw = float(cur[6])
    max_accel = max(float(cand_cfg.get("max_accel_mps2", 4.0)), 1e-3)
    max_decel = max(float(cand_cfg.get("max_decel_mps2", 6.0)), 1e-3)
    max_jerk = max(float(cand_cfg.get("max_jerk_mps3", 8.0)), 1e-3)
    max_yaw_rate = max(float(cand_cfg.get("max_yaw_rate_rad_s", 1.2)), 1e-3)
    horizon = int(pcfg.get("online_action_risk_horizon_steps", 8))
    horizon = max(1, min(horizon, int(candidates.shape[1]) if candidates.ndim >= 3 else 1))
    for k in range(K):
        if not bool(cand_valid[k]):
            out[k] = 1.0
            continue
        prev_speed = cur_speed
        prev_yaw = cur_yaw
        prev_accel = float(previous_longitudinal_accel)
        worst = 0.0
        for t in range(horizon):
            desired = candidates[k, t]
            desired_speed = float(np.linalg.norm(desired[3:5]))
            if desired_speed < 1e-3:
                base_xy = cur[:2] if t == 0 else candidates[k, t - 1, :2]
                desired_speed = float(np.linalg.norm(desired[:2] - base_xy) / dt)
            raw_accel = (desired_speed - prev_speed) / dt
            jerk_need = abs(raw_accel - prev_accel) / (max_jerk * dt)
            accel_excess = max(0.0, raw_accel - max_accel) / max_accel + max(0.0, -raw_accel - max_decel) / max_decel
            if desired_speed > 0.25:
                desired_yaw = float(np.arctan2(desired[4], desired[3]))
            else:
                desired_yaw = float(desired[2])
            yaw_need = abs(float(_wrap_angle(desired_yaw - prev_yaw))) / (max_yaw_rate * dt)
            # Early violations are most damaging because only the first action is
            # executed, but later spikes still indicate an inconsistent candidate.
            decay = 1.0 / (1.0 + 0.25 * float(t))
            step_risk = decay * (0.42 * max(0.0, jerk_need - 1.0) + 0.34 * max(0.0, yaw_need - 1.0) + 0.24 * accel_excess)
            worst = max(worst, step_risk)
            prev_speed = desired_speed
            prev_yaw = desired_yaw
            prev_accel = raw_accel
        out[k] = np.float32(np.clip(worst, 0.0, 1.0))
    return out


def build_online_batch(
    agent_state: np.ndarray,
    sdc_index: int,
    cfg: dict,
    *,
    history_model_state: np.ndarray | None = None,
    roadgraph: dict[str, np.ndarray] | None = None,
    other_future_trajs: np.ndarray | None = None,
    compute_rule_risk: bool = True,
    include_training_targets: bool = False,
) -> dict[str, Any]:
    K = int(cfg.get("limits", {}).get("max_candidates", 64))
    A = int(cfg.get("limits", {}).get("max_critical_agents", 8))
    M = int(cfg.get("limits", {}).get("max_natural_alternatives", 24))
    R = int(cfg.get("limits", {}).get("max_safe_responses", 32))
    H = int(cfg.get("time", {}).get("future_steps", cfg.get("eval", {}).get("rollout_horizon_steps", 80)))
    d_state = int(cfg.get("model", cfg).get("d_state", 11))
    max_agents = int(cfg.get("limits", {}).get("max_agents", cfg.get("model", cfg).get("max_agents", 128)))
    if roadgraph is None:
        roadgraph = {"xy": np.zeros((0, 2), dtype=np.float32), "heading": np.zeros(0, dtype=np.float32), "valid": np.zeros(0, dtype=bool), "types": np.zeros(0, dtype=np.int32)}
    if history_model_state is None:
        hist = np.zeros((max_agents, 1, d_state), dtype=np.float32)
        n = min(max_agents, agent_state.shape[0])
        hist[:n, 0, 0:3] = agent_state[:n, 0:3]
        hist[:n, 0, 3:6] = agent_state[:n, 7:10]
        hist[:n, 0, 6] = agent_state[:n, 6]
        hist[:n, 0, 7:9] = agent_state[:n, 3:5]
        hist[:n, 0, 9] = agent_state[:n, 5]
        hist[:n, 0, 10] = agent_state[:n, 10]
    else:
        hist = history_model_state.astype(np.float32, copy=False)
        n = min(max_agents, agent_state.shape[0])
    agent_mask = np.zeros(max_agents, dtype=bool)
    agent_mask[:n] = agent_state[:n, 10] > 0.5
    if 0 <= sdc_index < max_agents:
        agent_mask[sdc_index] = True

    cand_traj, cand_valid, conventional_safe, macro, utility = _route_lane_aware_candidates(
        agent_state, sdc_index, roadgraph, cfg, other_future_trajs=other_future_trajs
    )
    crit_idx, crit_valid = _critical_interaction_rank(agent_state, sdc_index, cand_traj, cand_valid, cfg)
    if compute_rule_risk:
        rule_risk = _candidate_rule_risk_np(
            agent_state, sdc_index, cand_traj, cand_valid, conventional_safe, crit_idx, crit_valid, cfg,
            other_future_trajs=other_future_trajs,
        )
    else:
        rule_risk = np.zeros(K, dtype=np.float32)
    conflict, conflict_valid = _online_conflict_tokens(agent_state, sdc_index, cand_traj, cand_valid, crit_idx, crit_valid, roadgraph, cfg)
    batch = {
        "state/history": hist[None],
        "state/agent_valid": agent_mask[None],
        "state/is_sdc": np.eye(max_agents, dtype=bool)[sdc_index][None] if 0 <= sdc_index < max_agents else np.zeros((1, max_agents), dtype=bool),
        "cowp/candidates/trajectory": cand_traj[None],
        "cowp/candidates/valid": cand_valid[None],
        "cowp/candidates/macro_type": macro[None],
        "cowp/candidates/ego_utility_prior": utility[None],
        "cowp/candidates/conventional_safe": conventional_safe[None],
        "cowp/candidates/rule_risk": rule_risk[None],
        "cowp/critical/track_index": crit_idx[None],
        "cowp/critical/input_index": crit_idx[None],
        "cowp/critical/valid": crit_valid[None],
        "map/conflict_regions": conflict[None],
        "map/conflict_region_valid": conflict_valid[None],
    }
    if include_training_targets:
        # Compatibility/debug-only targets.  They are intentionally omitted in the
        # default online path because the model inference keys above do not consume
        # them and allocating them at every Waymax step adds avoidable CPU work.
        batch.update({
            "cowp/natural/traj": np.zeros((1, A, M, H, 7), dtype=np.float32),
            "cowp/natural/valid": np.zeros((1, A, M), dtype=bool),
            "cowp/natural/weight": np.zeros((1, A, M), dtype=np.float32),
            "cowp/natural/source": np.zeros((1, A, M), dtype=np.int64),
            "cowp/natural/priority_preserved": np.zeros((1, A, M), dtype=bool),
            "cowp/response/valid": np.zeros((1, K, A, R), dtype=bool),
            "cowp/response/is_safe": np.zeros((1, K, A, R), dtype=bool),
            "cowp/response/is_low_burden": np.zeros((1, K, A, R), dtype=bool),
            "cowp/response/burden_total": np.zeros((1, K, A, R), dtype=np.float32),
            "cowp/response/burden_components": np.zeros((1, K, A, R, 6), dtype=np.float32),
            "cowp/witness/exists": np.zeros((1, K, A), dtype=bool),
            "cowp/witness/token": np.zeros((1, K, A), dtype=np.int64),
            "cowp/witness/burden_total": np.zeros((1, K, A), dtype=np.float32),
            "cowp/witness/burden_components": np.zeros((1, K, A, 6), dtype=np.float32),
            "cowp/witness/opr": np.ones((1, K, A), dtype=np.float32),
            "cowp/witness/c_i": np.zeros((1, K, A), dtype=np.float32),
            "cowp/witness/conflict_interval": np.zeros((1, K, A, 2), dtype=np.int64),
        })
    return batch


def _consistent_one_step_target(
    current: np.ndarray,
    desired: np.ndarray,
    cfg: dict,
    previous_longitudinal_accel: float = 0.0,
) -> tuple[np.ndarray, float]:
    """Convert a trajectory waypoint into a dynamically consistent 10 Hz state.

    Direct-state Waymax actions must not independently command position, yaw and
    velocity that contradict one another.  This controller integrates a jerk-
    limited longitudinal acceleration and yaw-rate-limited heading for one step.
    """
    dt = float(cfg.get("time", {}).get("dt", 0.1))
    cand_cfg = cfg.get("candidate", {})
    wm_cfg = cfg.get("waymax", {})
    cur_xy = np.asarray(current[:2], dtype=np.float64)
    cur_yaw = float(current[6])
    cur_vel = np.asarray(current[3:5], dtype=np.float64)
    cur_speed = float(max(np.linalg.norm(cur_vel), float(current[5]) if current.shape[0] > 5 else 0.0, 0.0))
    desired_vel = np.asarray(desired[3:5], dtype=np.float64) if desired.shape[0] >= 5 else np.zeros(2)
    desired_speed = float(np.linalg.norm(desired_vel))
    if desired_speed < 1e-3:
        desired_speed = float(np.linalg.norm(np.asarray(desired[:2], dtype=np.float64) - cur_xy) / max(dt, 1e-6))
    raw_accel = (desired_speed - cur_speed) / max(dt, 1e-6)
    max_accel = float(cand_cfg.get("max_accel_mps2", 4.0))
    max_decel = float(cand_cfg.get("max_decel_mps2", 6.0))
    max_jerk = float(cand_cfg.get("max_jerk_mps3", 8.0))
    raw_accel = float(np.clip(raw_accel, -max_decel, max_accel))
    accel = float(np.clip(raw_accel, previous_longitudinal_accel - max_jerk * dt, previous_longitudinal_accel + max_jerk * dt))
    next_speed = float(max(0.0, cur_speed + accel * dt))

    if desired_speed > 0.25:
        desired_yaw = float(np.arctan2(desired_vel[1], desired_vel[0]))
    else:
        desired_yaw = float(desired[2]) if desired.shape[0] > 2 else cur_yaw
    max_yaw_rate = float(cand_cfg.get("max_yaw_rate_rad_s", 1.2))
    max_dyaw = min(float(wm_cfg.get("max_delta_yaw_rad", 0.12)), max_yaw_rate * dt)
    dyaw = float(np.clip(_wrap_angle(desired_yaw - cur_yaw), -max_dyaw, max_dyaw))
    next_yaw = float(_wrap_angle(cur_yaw + dyaw))

    # Trapezoidal integration makes displacement and reported velocity mutually
    # consistent, reducing Waymax kinematic-infeasibility flags.
    v0 = cur_speed * np.asarray([np.cos(cur_yaw), np.sin(cur_yaw)], dtype=np.float64)
    v1 = next_speed * np.asarray([np.cos(next_yaw), np.sin(next_yaw)], dtype=np.float64)
    next_xy = cur_xy + 0.5 * (v0 + v1) * dt
    target = np.asarray([next_xy[0], next_xy[1], next_yaw, v1[0], v1[1]], dtype=np.float32)
    return target, accel



def _topk_frontier_mask_1d(base_mask, risk, tie_breaker=None, *, keep_frac=0.40, keep_min=1, keep_max=4, eps=1.0e-3):
    """Exact top-k frontier for one online scene.

    A quantile threshold keeps every tied candidate when certificate risk is
    flat, so COWP becomes conventional_safety.  Exact top-k preserves the
    intended set-valued feasibility layer.
    """
    import torch

    base = base_mask.bool()
    frontier = torch.zeros_like(base)
    if not bool(base.any().detach().cpu().item()):
        return frontier
    idx = torch.where(base)[0]
    n = int(idx.numel())
    k = max(int(keep_min), int(torch.ceil(torch.tensor(float(n) * float(keep_frac), device=risk.device)).item()))
    k = min(max(k, 1), n, max(int(keep_max), 1))
    r = torch.nan_to_num(risk[idx].float(), nan=1.0, posinf=1.0, neginf=0.0)
    if tie_breaker is None:
        tb = torch.arange(n, device=risk.device, dtype=r.dtype) / max(float(n), 1.0)
    else:
        tb = torch.nan_to_num(tie_breaker[idx].float(), nan=0.0, posinf=1.0, neginf=0.0)
        if tb.numel() > 1:
            lo = tb.min(); hi = tb.max(); span = (hi - lo).clamp_min(1.0e-6)
            tb = ((tb - lo) / span).clamp(0.0, 1.0)
        else:
            tb = torch.zeros_like(tb)
    order = torch.argsort(r + float(eps) * tb, stable=True)
    frontier[idx[order[:k]]] = True
    return frontier

def _guard_frontier_base_1d(base, score_risk, progress, action_risk=None, *, keep_min=2, pcfg=None):
    import torch
    pcfg = pcfg or {}
    base = base.bool()
    if not bool(base.any().detach().cpu().item()):
        return base
    idx = torch.where(base)[0]
    need = min(max(int(keep_min), 1), int(idx.numel()))
    guarded = base.clone()
    if torch.is_tensor(progress) and progress.numel() == base.numel():
        vals = torch.nan_to_num(progress.float(), nan=0.0, posinf=0.0, neginf=0.0)
        p_ref = vals[idx].max() if idx.numel() else vals.new_tensor(0.0)
        min_abs = float(pcfg.get("candidate_frontier_min_progress_m", 1.0))
        ratio = float(pcfg.get("candidate_frontier_min_progress_ratio", 0.12))
        if float(p_ref.detach().cpu().item()) > min_abs:
            pg = base & (vals >= max(min_abs, ratio * float(p_ref.detach().cpu().item())))
            if int(pg.sum().detach().cpu().item()) >= need:
                guarded = pg
    if torch.is_tensor(score_risk) and score_risk.numel() == base.numel():
        sr = torch.nan_to_num(score_risk.float(), nan=1.0, posinf=1.0, neginf=0.0)
        best = sr[idx].min() if idx.numel() else sr.new_tensor(0.0)
        sg = base & (sr <= best + float(pcfg.get("candidate_frontier_score_slack", 0.85)))
        joint = guarded & sg
        if int(joint.sum().detach().cpu().item()) >= need:
            guarded = joint
    if torch.is_tensor(action_risk) and action_risk.numel() == base.numel():
        ar = torch.nan_to_num(action_risk.float(), nan=1.0, posinf=1.0, neginf=0.0)
        ag = guarded & (ar <= float(pcfg.get("candidate_frontier_max_action_risk", 0.90)))
        if int(ag.sum().detach().cpu().item()) >= need:
            guarded = ag
    return guarded


@dataclass
class COWPWaymaxPolicy:
    checkpoint: str
    cfg: dict
    device: str = "auto"
    witness_threshold: float = 0.5
    action_mode: str = "delta_xy_yaw"
    ncf_gate_mode: str = "hard"
    priority_hard_threshold: float = 0.55
    secondary_witness_threshold: float = 0.85
    secondary_opr_alpha: float = 0.10
    soft_ncf_penalty: float = 1.5
    method: str = "cowp"
    adaptive_frontier_margin: float = 0.20
    outcome_risk_penalty: float = 0.0
    outcome_risk_threshold: float = 1.10

    def __post_init__(self) -> None:
        import torch

        from cowp.models.cowp_model import COWPModel

        dev = torch.device("cuda" if self.device == "auto" and torch.cuda.is_available() else ("cpu" if self.device == "auto" else self.device))
        ckpt = torch.load(self.checkpoint, map_location="cpu")
        model_cfg = ckpt.get("cfg", self.cfg)
        self.model = COWPModel(model_cfg)
        _load_state_dict_compatible(self.model, ckpt["model"])
        del ckpt
        self.model.to(dev)
        self.model.eval()
        self.torch = torch
        self.dev = dev
        if dev.type == "cuda":
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass
        self._last_diagnostics: dict[str, Any] | None = None
        self._diagnostics_log: list[dict[str, Any]] = []
        self._previous_longitudinal_accel: float = 0.0
        self._previous_scenario_index: int | None = None
        self._cached_roadgraph_scenario_index: int | None = None
        self._cached_roadgraph: dict[str, np.ndarray] | None = None

    def _trajectory_to_action(self, state: Any, agent_state: np.ndarray, sdc_index: int, traj: np.ndarray) -> Any:
        try:
            from waymax import datatypes  # type: ignore
        except Exception as exc:  # pragma: no cover
            raise ImportError("waymax.datatypes is required to convert a selected COWP trajectory to a Waymax action.") from exc
        N = agent_state.shape[0]
        data_dim = int(self.cfg.get("waymax", {}).get("action_dim", 3))
        if self.action_mode == "absolute_xy_yaw":
            data_dim = max(data_dim, 5)
        data = np.zeros((N, data_dim), dtype=np.float32)
        valid = np.zeros((N, 1), dtype=bool)
        valid[sdc_index, 0] = True
        desired = traj[0]
        target, accel = _consistent_one_step_target(
            agent_state[sdc_index], desired, self.cfg, self._previous_longitudinal_accel
        )
        self._previous_longitudinal_accel = float(accel)
        if self.action_mode == "absolute_xy_yaw":
            data[sdc_index, :5] = target
        else:
            dx = float(target[0] - agent_state[sdc_index, 0])
            dy = float(target[1] - agent_state[sdc_index, 1])
            dyaw = float(_wrap_angle(float(target[2] - agent_state[sdc_index, 6])))
            data[sdc_index, : min(data_dim, 3)] = np.asarray([dx, dy, dyaw], dtype=np.float32)[:data_dim]
        data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        try:
            import jax.numpy as jnp  # type: ignore
            return datatypes.Action(data=jnp.asarray(data), valid=jnp.asarray(valid))
        except Exception:
            return datatypes.Action(data=data, valid=valid)

    def __call__(self, state: Any, *, step: int | None = None, scenario_index: int | None = None) -> Any:
        if step == 0 or (scenario_index is not None and scenario_index != self._previous_scenario_index):
            self._previous_longitudinal_accel = 0.0
        self._previous_scenario_index = scenario_index
        method, gate_mode = _canonical_online_method(getattr(self, "method", "cowp"), self.ncf_gate_mode)
        needs_cowp_risk = method not in {"planner_score_only", "conventional_safety", "idm_lattice"}
        history, agent_state, sdc_index = extract_agent_history_model_state(state, self.cfg)
        if scenario_index is not None and self._cached_roadgraph_scenario_index == int(scenario_index) and self._cached_roadgraph is not None:
            roadgraph = self._cached_roadgraph
        else:
            roadgraph = _extract_roadgraph_tokens(state, self.cfg)
            if scenario_index is not None:
                self._cached_roadgraph_scenario_index = int(scenario_index)
                self._cached_roadgraph = roadgraph
        other_future_trajs = _extract_logged_future_agent_trajs(state, sdc_index, self.cfg)
        batch_np = build_online_batch(
            agent_state, sdc_index, self.cfg, history_model_state=history, roadgraph=roadgraph,
            other_future_trajs=other_future_trajs, compute_rule_risk=needs_cowp_risk,
        )
        online_keys = (
            "state/history",
            "state/agent_valid",
            "state/is_sdc",
            "cowp/candidates/trajectory",
            "cowp/candidates/valid",
            "cowp/candidates/macro_type",
            "cowp/candidates/ego_utility_prior",
            "cowp/candidates/conventional_safe",
            "cowp/candidates/rule_risk",
            "cowp/critical/track_index",
            "cowp/critical/input_index",
            "cowp/critical/valid",
            "map/conflict_regions",
            "map/conflict_region_valid",
        )
        batch = {k: self.torch.as_tensor(batch_np[k], device=self.dev) for k in online_keys if k in batch_np}
        with self.torch.inference_mode():
            pred = self.model(batch, stage="planner")
            scores = self.torch.nan_to_num(pred["planner_score"][0].float(), nan=1e6, posinf=1e6, neginf=-1e6)
            cand_valid = batch["cowp/candidates/valid"][0].bool()
            # One host synchronization for a predicate reused throughout the
            # decision path.  The previous implementation queried any(valid)
            # repeatedly inside normalization and diagnostics, forcing the CUDA
            # stream to synchronize many times per simulator step.
            has_valid = bool(cand_valid.any().detach().cpu().item())
            conventional = batch.get("cowp/candidates/conventional_safe", batch["cowp/candidates/valid"])[0].bool()
            utility = batch.get("cowp/candidates/ego_utility_prior", None)
            utility_scores = self.torch.nan_to_num(utility[0].float(), nan=1e6, posinf=1e6, neginf=-1e6) if utility is not None else scores

            if not needs_cowp_risk:
                # Fast exact-equivalent path for internal baselines.  These methods
                # do not use witness, priority, pressure, rule, action, or outcome
                # risk in selection, so skip those expensive online computations.
                if method == "idm_lattice":
                    select_mask = cand_valid & conventional
                    adjusted_scores = utility_scores
                elif method == "conventional_safety":
                    select_mask = cand_valid & conventional
                    adjusted_scores = scores
                else:  # planner_score_only
                    select_mask = cand_valid
                    adjusted_scores = scores
                fallback_used = False
                fallback_reason = "accepted_baseline"
                macro_t = batch["cowp/candidates/macro_type"][0].long()
                stop_ids = self.torch.as_tensor(
                    [int(MacroType.STOP_BEFORE_CONFLICT), int(MacroType.YIELD), int(MacroType.CREEP), int(MacroType.NEUTRAL_EGO)],
                    device=self.dev, dtype=macro_t.dtype,
                )
                stop_like = (macro_t[:, None] == stop_ids[None, :]).any(dim=-1)
                has_select = bool(select_mask.any().detach().cpu().item())
                if not has_select:
                    fallback_used = True
                    if bool((cand_valid & stop_like).any().detach().cpu().item()):
                        select_mask = cand_valid & stop_like
                        fallback_reason = "baseline_use_stop_like"
                    else:
                        select_mask = cand_valid
                        fallback_reason = "baseline_use_valid"
                    has_select = has_valid
                selected = int(self.torch.argmin(self.torch.where(select_mask, adjusted_scores, self.torch.full_like(adjusted_scores, float("inf")))).item()) if has_select else 0
                baseline_host = self.torch.stack([
                    select_mask.sum().float(),
                    cand_valid.sum().float(),
                    (cand_valid & conventional).sum().float(),
                    batch["cowp/critical/valid"][0].bool().sum().float(),
                    batch["map/conflict_region_valid"][0].bool().sum().float(),
                    scores[selected].float(),
                ]).detach().cpu().tolist()
                diag = {
                    "scenario_index": int(scenario_index) if scenario_index is not None else -1,
                    "step": int(step) if step is not None else -1,
                    "selected_candidate": int(selected),
                    "accepted_candidates": int(baseline_host[0]),
                    "frontier_candidates": -1,
                    "valid_candidates": int(baseline_host[1]),
                    "conventional_candidates": int(baseline_host[2]),
                    "critical_agents": int(baseline_host[3]),
                    "conflict_tokens": int(baseline_host[4]),
                    "fallback_used": bool(fallback_used),
                    "fallback_reason": fallback_reason,
                    "max_witness_prob": 0.0,
                    "mean_witness_prob": 0.0,
                    "mean_witness_uncertainty": 0.0,
                    "max_witness_certificate": 0.0,
                    "min_opr": 1.0,
                    "mean_opr": 1.0,
                    "score": float(baseline_host[5]),
                    "witness_threshold": float(self.witness_threshold),
                    "alpha_opr": float(self.cfg.get("planning", {}).get("alpha_opr_infer", self.cfg.get("ncf", {}).get("alpha_opr", 0.35))),
                    "gate_mode": str(gate_mode),
                    "method": str(method),
                    "priority_hard_threshold": float(self.priority_hard_threshold),
                    "accepted_primary_bad_candidates": 0,
                    "severe_bad_candidates": 0,
                    "option_bad_candidates": 0,
                    "selected_priority_max": 0.0,
                    "selected_priority_mean": 0.0,
                    "selected_outcome_risk": 0.0,
                    "selected_outcome_decision_risk": 0.0,
                    "selected_candidate_ncf_prob": 0.0,
                    "selected_candidate_false_safe_prob": 0.0,
                    "selected_candidate_quality_prob": 0.0,
                    "selected_candidate_cert_risk": 0.0,
                    "selected_candidate_pressure_prior": 0.0,
                    "selected_candidate_rule_risk": 0.0,
                    "selected_candidate_action_risk": 0.0,
                    "min_candidate_cert_risk": 0.0,
                    "mean_candidate_cert_risk": 0.0,
                    "mean_candidate_pressure_prior": 0.0,
                    "mean_candidate_rule_risk": 0.0,
                    "mean_candidate_action_risk": 0.0,
                    "beta_threshold": float(self.cfg.get("burden", {}).get("beta0_vehicle", 0.65)),
                }
                self._last_diagnostics = diag
                self._diagnostics_log.append(diag)
                traj = batch_np["cowp/candidates/trajectory"][0, selected]
                return self._trajectory_to_action(state, agent_state, sdc_index, traj)

            pcfg = self.cfg.get("planning", {})
            temp = max(float(pcfg.get("witness_temperature", 1.0)), 1e-3)
            bias = float(pcfg.get("witness_logit_bias", 0.0))
            logit_witness = self.torch.sigmoid((pred["witness"]["exist_logits"][0].float() - bias) / temp)
            evidence_witness = pred["witness"].get("evidential_prob")
            uncertainty = pred["witness"].get("epistemic_uncertainty")
            source = str(pcfg.get("witness_probability_source", "mixed")).lower()
            if source == "logit" or not self.torch.is_tensor(evidence_witness):
                witness = logit_witness
            elif source == "evidential":
                witness = evidence_witness[0].float()
            else:
                mix = float(pcfg.get("evidential_probability_mix", 0.5))
                witness = (1.0 - mix) * logit_witness + mix * evidence_witness[0].float()
            if self.torch.is_tensor(uncertainty):
                uncertainty = uncertainty[0].float().clamp(0.0, 1.0)
            else:
                uncertainty = self.torch.zeros_like(witness)
            witness = self.torch.nan_to_num(witness, nan=1.0, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)
            uncertainty = self.torch.nan_to_num(uncertainty, nan=1.0, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)
            ucb_scale = float(pcfg.get("evidential_ucb_scale", 0.0 if source == "logit" else 0.15))
            witness_cert = (witness + ucb_scale * uncertainty).clamp(0.0, 1.0)
            opr = self.torch.nan_to_num(pred["witness"]["opr"][0].float(), nan=0.0, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)
            burden = pred["witness"].get("burden_total")
            c_i = pred["witness"].get("c_i")
            outcome = pred.get("outcome", {})
            cand_ncf_logit = pred.get("candidate_ncf_logit")
            cand_fs_logit = pred.get("candidate_false_safe_logit")
            cand_quality_logit = pred.get("candidate_quality_logit")
            if self.torch.is_tensor(cand_ncf_logit):
                cand_ncf_prob = self.torch.sigmoid(self.torch.nan_to_num(cand_ncf_logit[0].float(), nan=0.0, posinf=20.0, neginf=-20.0))
            else:
                cand_ncf_prob = self.torch.sigmoid(self.torch.nan_to_num(-scores, nan=0.0, posinf=20.0, neginf=-20.0))
            if self.torch.is_tensor(cand_fs_logit):
                cand_false_safe_prob = self.torch.sigmoid(self.torch.nan_to_num(cand_fs_logit[0].float(), nan=0.0, posinf=20.0, neginf=-20.0))
            else:
                cand_false_safe_prob = self.torch.sigmoid(self.torch.nan_to_num(scores, nan=0.0, posinf=20.0, neginf=-20.0))
            if self.torch.is_tensor(cand_quality_logit):
                cand_quality_prob = self.torch.sigmoid(self.torch.nan_to_num(cand_quality_logit[0].float(), nan=0.0, posinf=20.0, neginf=-20.0))
            else:
                cand_quality_prob = cand_ncf_prob * (1.0 - cand_false_safe_prob)
            pcfg_runtime = self.cfg.get("planning", {})
            candidate_cert_risk = (
                float(pcfg_runtime.get("candidate_risk_ncf_weight", 1.0)) * (1.0 - cand_ncf_prob.clamp(0.0, 1.0))
                + float(pcfg_runtime.get("candidate_risk_false_safe_weight", 2.0)) * cand_false_safe_prob.clamp(0.0, 1.0)
                + float(pcfg_runtime.get("candidate_risk_quality_weight", 0.75)) * (1.0 - cand_quality_prob.clamp(0.0, 1.0))
            )
            pressure_np = _candidate_pressure_prior_np(
                agent_state,
                sdc_index,
                batch_np["cowp/candidates/trajectory"][0],
                batch_np["cowp/candidates/valid"][0].astype(bool),
                batch_np["cowp/critical/track_index"][0],
                batch_np["cowp/critical/valid"][0].astype(bool),
                batch_np["cowp/candidates/macro_type"][0],
                self.cfg,
                other_future_trajs=other_future_trajs,
            )
            pressure_prior = self.torch.as_tensor(pressure_np, device=self.dev, dtype=scores.dtype).clamp(0.0, 1.0)
            rule_risk_t = batch.get("cowp/candidates/rule_risk")
            if self.torch.is_tensor(rule_risk_t):
                rule_risk = self.torch.nan_to_num(rule_risk_t[0].float(), nan=1.0, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)
            else:
                rule_risk = self.torch.zeros_like(scores)
            action_risk_np = _one_step_action_risk_np(
                agent_state,
                sdc_index,
                batch_np["cowp/candidates/trajectory"][0],
                batch_np["cowp/candidates/valid"][0].astype(bool),
                self.cfg,
                self._previous_longitudinal_accel,
            )
            action_risk = self.torch.as_tensor(action_risk_np, device=self.dev, dtype=scores.dtype).clamp(0.0, 1.0)

            def _scene_norm(x):
                x = self.torch.nan_to_num(x.float(), nan=0.0, posinf=1.0, neginf=0.0)
                if not has_valid:
                    return self.torch.zeros_like(x)
                vals = x[cand_valid]
                lo = vals.min()
                hi = vals.quantile(0.90) if vals.numel() > 1 else vals.max()
                span = (hi - lo).clamp_min(float(self.cfg.get("planning", {}).get("decision_risk_min_spread", 1e-3)))
                y = ((x - lo) / span).clamp(0.0, 1.0)
                spread = vals.std(unbiased=False) if vals.numel() > 1 else self.torch.tensor(0.0, device=self.dev, dtype=x.dtype)
                return self.torch.where(spread >= float(self.cfg.get("planning", {}).get("decision_risk_min_std", 1e-3)), y, self.torch.zeros_like(y))

            cert_decision_risk = _scene_norm(candidate_cert_risk)
            pressure_decision_risk = _scene_norm(pressure_prior)
            rule_decision_risk = _scene_norm(rule_risk)
            action_decision_risk = _scene_norm(action_risk)
            score_decision_risk = _scene_norm(scores)
            traj_t = batch.get("cowp/candidates/trajectory")
            if self.torch.is_tensor(traj_t) and traj_t.ndim >= 4:
                xy0 = traj_t[0, :, 0, :2].float()
                xy1 = traj_t[0, :, -1, :2].float()
                candidate_progress = self.torch.linalg.norm(self.torch.nan_to_num(xy1 - xy0, nan=0.0, posinf=0.0, neginf=0.0), dim=-1)
                candidate_progress = self.torch.where(cand_valid, candidate_progress, self.torch.zeros_like(candidate_progress))
            else:
                candidate_progress = self.torch.zeros_like(scores)
            progress_ref = candidate_progress[cand_valid].max().clamp_min(1.0e-6) if has_valid else self.torch.tensor(1.0, device=self.dev, dtype=scores.dtype)
            progress_shortfall = (1.0 - (candidate_progress / progress_ref).clamp(0.0, 1.0)).clamp(0.0, 1.0)
            if isinstance(outcome, dict) and float(self.outcome_risk_penalty) > 0.0:
                col_r = self.torch.sigmoid(outcome.get("collision_logit", self.torch.zeros_like(scores))[0].float())
                off_r = self.torch.sigmoid(outcome.get("offroad_logit", self.torch.zeros_like(scores))[0].float())
                ld_r = outcome.get("logdiv", self.torch.zeros_like(scores))[0].float().clamp_min(0.0) / 10.0
                outcome_risk = self.torch.nan_to_num(col_r + off_r + ld_r, nan=1.0, posinf=10.0, neginf=0.0)
            else:
                outcome_risk = self.torch.zeros_like(scores)
            outcome_decision_risk = _scene_norm(outcome_risk)

            # Hybrid outcome-calibrated certificate for online COWP.  If the newly
            # added candidate certificate head is still flat after a resumed run,
            # using it directly makes all certificate risks identical and COWP
            # degenerates to conventional_safety.  In that case, replace most of
            # the certificate with a calibrated fallback from the outcome head plus
            # rule/action/pressure priors.  When the certificate head has spread,
            # keep it as the primary signal and only add a small stabilizing mix.
            fallback_cert_risk = (
                float(pcfg_runtime.get("candidate_cert_fallback_outcome_mix", 0.55)) * outcome_decision_risk
                + float(pcfg_runtime.get("candidate_cert_fallback_action_mix", 0.20)) * action_decision_risk
                + float(pcfg_runtime.get("candidate_cert_fallback_rule_mix", 0.15)) * rule_decision_risk
                + float(pcfg_runtime.get("candidate_cert_fallback_pressure_mix", 0.10)) * pressure_decision_risk
            ).clamp(0.0, 1.0)
            raw_vals = candidate_cert_risk[cand_valid] if has_valid else candidate_cert_risk[:0]
            raw_spread = raw_vals.float().std(unbiased=False) if raw_vals.numel() > 1 else self.torch.tensor(0.0, device=self.dev, dtype=scores.dtype)
            flat_cert = bool((raw_spread < float(pcfg_runtime.get("candidate_cert_fallback_min_std", 2.0e-3))).detach().cpu().item())
            mix_value = float(pcfg_runtime.get("candidate_cert_flat_fallback_mix", 0.90) if flat_cert else pcfg_runtime.get("candidate_cert_hybrid_fallback_mix", 0.25))
            cert_decision_risk = ((1.0 - mix_value) * cert_decision_risk + mix_value * fallback_cert_risk).clamp(0.0, 1.0)
            fb_ncf = (1.0 - fallback_cert_risk).clamp(0.02, 0.98)
            fb_fs = fallback_cert_risk.clamp(0.02, 0.98)
            fb_q = (1.0 - fallback_cert_risk).clamp(0.02, 0.98)
            cand_ncf_prob = ((1.0 - mix_value) * cand_ncf_prob + mix_value * fb_ncf).clamp(0.0, 1.0)
            cand_false_safe_prob = ((1.0 - mix_value) * cand_false_safe_prob + mix_value * fb_fs).clamp(0.0, 1.0)
            cand_quality_prob = ((1.0 - mix_value) * cand_quality_prob + mix_value * fb_q).clamp(0.0, 1.0)
            candidate_cert_risk = cert_decision_risk

            crit_mask = batch["cowp/critical/valid"][0].bool()
            witness = self.torch.where(crit_mask[None, :], witness, self.torch.zeros_like(witness))
            witness_cert = self.torch.where(crit_mask[None, :], witness_cert, self.torch.zeros_like(witness_cert))
            uncertainty = self.torch.where(crit_mask[None, :], uncertainty, self.torch.zeros_like(uncertainty))
            opr = self.torch.where(crit_mask[None, :], opr, self.torch.ones_like(opr))
            alpha = float(self.cfg.get("planning", {}).get("alpha_opr_infer", self.cfg.get("ncf", {}).get("alpha_opr", 0.35)))
            adjusted_scores = scores
            priority = self.torch.zeros_like(witness)
            primary_bad = self.torch.zeros_like(cand_valid)
            severe_bad = self.torch.zeros_like(cand_valid)
            option_bad = self.torch.zeros_like(cand_valid)
            if method == "idm_lattice":
                accepted = cand_valid & conventional
                adjusted_scores = utility_scores
            elif method == "conventional_safety":
                accepted = cand_valid & conventional
            elif method == "planner_score_only":
                accepted = cand_valid
            elif gate_mode == "hard":
                predicted_bad = (witness_cert >= float(self.witness_threshold)).any(dim=-1)
                accepted = cand_valid & conventional & ~predicted_bad
                accepted = accepted & (opr.min(dim=-1).values >= alpha)
            else:
                priority_np = _priority_claim_weights(
                    agent_state,
                    sdc_index,
                    batch_np["cowp/candidates/trajectory"][0],
                    batch_np["cowp/candidates/valid"][0].astype(bool),
                    batch_np["cowp/critical/track_index"][0],
                    batch_np["cowp/critical/valid"][0].astype(bool),
                    batch_np["cowp/candidates/macro_type"][0],
                    self.cfg,
                )
                heuristic_priority = self.torch.as_tensor(priority_np, device=self.dev, dtype=witness.dtype)
                learned_priority = pred.get("priority_claim_logits")
                if self.torch.is_tensor(learned_priority):
                    learned_priority = self.torch.sigmoid(learned_priority[0].float())
                    # Before the new head is trained it may be uncalibrated; blend with
                    # the physically grounded heuristic rather than replacing it.
                    priority = 0.5 * heuristic_priority + 0.5 * learned_priority
                else:
                    priority = heuristic_priority
                primary_claim = priority >= float(self.priority_hard_threshold)
                primary_bad = ((witness_cert >= float(self.witness_threshold)) & primary_claim).any(dim=-1)
                option_bad = ((opr < alpha) & primary_claim).any(dim=-1)
                severe_bad = ((witness_cert >= float(self.secondary_witness_threshold)) & (opr <= float(self.secondary_opr_alpha)) & primary_claim).any(dim=-1)
                burden_penalty = (witness * priority).amax(dim=-1)
                option_penalty = (self.torch.relu(alpha - opr) * priority).amax(dim=-1)
                cert_penalty = float(self.cfg.get("planning", {}).get("candidate_certificate_penalty", 1.0))
                pressure_penalty = float(self.cfg.get("planning", {}).get("candidate_pressure_prior_penalty", 0.75))
                rule_penalty = float(self.cfg.get("planning", {}).get("candidate_rule_risk_penalty", 1.25))
                action_penalty = float(self.cfg.get("planning", {}).get("candidate_action_risk_penalty", 1.0))
                adjusted_scores = (
                    scores
                    + float(self.soft_ncf_penalty) * (burden_penalty + option_penalty)
                    + cert_penalty * cert_decision_risk
                    + pressure_penalty * pressure_decision_risk
                    + rule_penalty * rule_decision_risk
                    + action_penalty * action_decision_risk
                    + float(self.outcome_risk_penalty) * outcome_decision_risk
                )
                if gate_mode == "soft":
                    accepted = cand_valid & conventional
                elif gate_mode in {"none", "off"}:
                    accepted = cand_valid & conventional
                else:
                    accepted = cand_valid & conventional & ~primary_bad & ~option_bad & ~severe_bad & (outcome_risk <= float(self.outcome_risk_threshold))
            # Scene-adaptive feasibility frontier.  If the absolute witness/OPR
            # calibration is imperfect, restrict COWP to the least-coercive
            # conventional frontier in the current scene.  This makes the online
            # controller consistent with the set-valued NCF certificate used in
            # learned-offline evaluation.
            if method == "cowp" and gate_mode in {"priority", "soft"}:
                frontier_base = cand_valid & conventional & (outcome_risk <= float(self.outcome_risk_threshold))
                if frontier_base.any():
                    if 'priority' in locals() and priority.numel():
                        pair_risk = (witness * priority).amax(dim=-1) + (self.torch.relu(alpha - opr) * priority).amax(dim=-1)
                    else:
                        pair_risk = witness.amax(dim=-1) + self.torch.relu(alpha - opr).amax(dim=-1)
                    pair_mix = float(self.cfg.get("planning", {}).get("candidate_pair_risk_mix", 0.10))
                    pressure_mix = float(self.cfg.get("planning", {}).get("candidate_pressure_prior_mix", 0.75))
                    rule_mix = float(self.cfg.get("planning", {}).get("candidate_rule_risk_mix", 1.25))
                    action_mix = float(self.cfg.get("planning", {}).get("candidate_action_risk_mix", 1.0))
                    outcome_mix = float(self.cfg.get("planning", {}).get("candidate_outcome_risk_mix", float(self.outcome_risk_penalty)))
                    frontier_risk = (
                        cert_decision_risk
                        + pair_mix * pair_risk
                        + pressure_mix * pressure_decision_risk
                        + rule_mix * rule_decision_risk
                        + action_mix * action_decision_risk
                        + outcome_mix * outcome_decision_risk
                    )
                    keep_frac = float(self.cfg.get("planning", {}).get("candidate_frontier_keep_fraction", 0.40))
                    keep_min = int(self.cfg.get("planning", {}).get("candidate_frontier_min_keep", 1))
                    keep_max = int(self.cfg.get("planning", {}).get("candidate_frontier_max_keep", 4))
                    guarded_base = _guard_frontier_base_1d(
                        frontier_base, score_decision_risk, candidate_progress, action_decision_risk,
                        keep_min=keep_min, pcfg=self.cfg.get("planning", {}),
                    )
                    idx = self.torch.where(guarded_base)[0]
                    if idx.numel() > 0:
                        k = max(keep_min, int(self.torch.ceil(self.torch.tensor(float(idx.numel()) * keep_frac, device=self.dev)).item()))
                        k = min(max(k, 1), int(idx.numel()), max(keep_max, 1))
                        # Exact-cardinality frontier.  A threshold cutoff would
                        # keep every tied candidate when certificate/outcome risk is
                        # flat, which is exactly how COWP collapsed to
                        # conventional_safety in v2.
                        tie = (
                            0.70 * score_decision_risk
                            + 0.20 * progress_shortfall
                            + 0.25 * outcome_decision_risk
                            + 0.10 * action_decision_risk
                        )
                        frontier = _topk_frontier_mask_1d(
                            guarded_base, frontier_risk, tie,
                            keep_frac=keep_frac, keep_min=keep_min, keep_max=keep_max,
                            eps=float(self.cfg.get("planning", {}).get("candidate_frontier_tie_eps", 1.0e-3)),
                        )
                        min_ncf = float(self.cfg.get("planning", {}).get("candidate_min_ncf_prob", 0.05))
                        max_fs = float(self.cfg.get("planning", {}).get("candidate_max_false_safe_prob", 0.95))
                        screened = frontier & (cand_ncf_prob >= min_ncf) & (cand_false_safe_prob <= max_fs)
                        if bool(screened.any().detach().cpu().item()):
                            frontier = screened
                        if bool(frontier.any().detach().cpu().item()):
                            accepted = frontier
                            adjusted_scores = adjusted_scores + frontier_risk
            # Conservative fallback hierarchy: first accepted P-NCF/NCF; then a
            # neutral/stop-like conventional candidate; finally the guaranteed
            # neutral candidate.  Avoid falling back to an arbitrary conventional
            # false-safe plan, which hid the effect of NCF rejection in the smoke test.
            macro_t = batch["cowp/candidates/macro_type"][0].long()
            stop_ids = self.torch.as_tensor(
                [int(MacroType.STOP_BEFORE_CONFLICT), int(MacroType.YIELD), int(MacroType.CREEP), int(MacroType.NEUTRAL_EGO)],
                device=self.dev,
                dtype=macro_t.dtype,
            )
            stop_like = (macro_t[:, None] == stop_ids[None, :]).any(dim=-1)
            fallback_flags = self.torch.stack([
                accepted.any(),
                (cand_valid & conventional & stop_like).any(),
                (cand_valid & stop_like).any(),
                (cand_valid & conventional).any(),
            ]).detach().cpu().tolist()
            if bool(fallback_flags[0]):
                select_mask = accepted
                fallback_used = False
                fallback_reason = "accepted_ncf" if gate_mode == "hard" else ("accepted_baseline" if gate_mode in {"none", "off"} else "accepted_priority_ncf")
            elif bool(fallback_flags[1]):
                select_mask = cand_valid & conventional & stop_like
                fallback_used = True
                fallback_reason = "no_ncf_use_stop_like"
            elif bool(fallback_flags[2]):
                select_mask = cand_valid & stop_like
                fallback_used = True
                fallback_reason = "no_conventional_use_neutral"
            elif bool(fallback_flags[3]):
                select_mask = cand_valid & conventional
                fallback_used = True
                fallback_reason = "no_stop_like_use_conventional"
            else:
                select_mask = cand_valid
                fallback_used = True
                fallback_reason = "no_conventional_use_valid"
            selected = int(self.torch.argmin(self.torch.where(select_mask, adjusted_scores, self.torch.full_like(adjusted_scores, float("inf")))).item()) if has_valid else 0
            selected_witness = witness[selected]
            selected_opr = opr[selected]
            has_crit = bool(crit_mask.any().detach().cpu().item())
            zero = scores.new_tensor(0.0)
            one = scores.new_tensor(1.0)
            frontier_count = frontier.sum().float() if "frontier" in locals() and self.torch.is_tensor(frontier) else scores.new_tensor(-1.0)
            valid_cert = candidate_cert_risk[cand_valid] if has_valid else candidate_cert_risk[:0]
            valid_pressure = pressure_prior[cand_valid] if has_valid else pressure_prior[:0]
            valid_rule = rule_risk[cand_valid] if has_valid else rule_risk[:0]
            valid_action = action_risk[cand_valid] if has_valid else action_risk[:0]
            bsel = self.torch.nan_to_num(burden[0, selected].float(), nan=0.0, posinf=2.0, neginf=0.0) if burden is not None else None
            csel = self.torch.nan_to_num(c_i[0, selected].float(), nan=0.0, posinf=2.0, neginf=0.0) if c_i is not None else None
            diagnostic_tensors = [
                accepted.sum().float(),
                frontier_count,
                cand_valid.sum().float(),
                (cand_valid & conventional).sum().float(),
                crit_mask.sum().float(),
                batch["map/conflict_region_valid"][0].bool().sum().float(),
                selected_witness.max() if selected_witness.numel() else zero,
                selected_witness.mean() if selected_witness.numel() else zero,
                uncertainty[selected].mean() if uncertainty[selected].numel() else zero,
                witness_cert[selected].max() if witness_cert[selected].numel() else zero,
                selected_opr.min() if selected_opr.numel() else one,
                selected_opr.mean() if selected_opr.numel() else one,
                scores[selected],
                primary_bad.sum().float() if primary_bad.numel() else zero,
                severe_bad.sum().float() if severe_bad.numel() else zero,
                option_bad.sum().float() if option_bad.numel() else zero,
                priority[selected].max() if priority.numel() else zero,
                priority[selected].mean() if priority.numel() else zero,
                outcome_risk[selected] if outcome_risk.numel() else zero,
                outcome_decision_risk[selected] if outcome_decision_risk.numel() else zero,
                cand_ncf_prob[selected] if cand_ncf_prob.numel() else zero,
                cand_false_safe_prob[selected] if cand_false_safe_prob.numel() else zero,
                cand_quality_prob[selected] if cand_quality_prob.numel() else zero,
                candidate_cert_risk[selected] if candidate_cert_risk.numel() else zero,
                pressure_prior[selected] if pressure_prior.numel() else zero,
                rule_risk[selected] if rule_risk.numel() else zero,
                action_risk[selected] if action_risk.numel() else zero,
                valid_cert.min() if valid_cert.numel() else zero,
                valid_cert.mean() if valid_cert.numel() else zero,
                valid_pressure.mean() if valid_pressure.numel() else zero,
                valid_rule.mean() if valid_rule.numel() else zero,
                valid_action.mean() if valid_action.numel() else zero,
                bsel[crit_mask].max() if bsel is not None and has_crit else zero,
                csel[crit_mask].max() if csel is not None and has_crit else zero,
            ]
            host = self.torch.stack([x.float() for x in diagnostic_tensors]).detach().cpu().tolist()
            diag = {
                "scenario_index": int(scenario_index) if scenario_index is not None else -1,
                "step": int(step) if step is not None else -1,
                "selected_candidate": int(selected),
                "accepted_candidates": int(host[0]),
                "frontier_candidates": int(host[1]),
                "valid_candidates": int(host[2]),
                "conventional_candidates": int(host[3]),
                "critical_agents": int(host[4]),
                "conflict_tokens": int(host[5]),
                "fallback_used": bool(fallback_used),
                "fallback_reason": fallback_reason,
                "max_witness_prob": float(host[6]),
                "mean_witness_prob": float(host[7]),
                "mean_witness_uncertainty": float(host[8]),
                "max_witness_certificate": float(host[9]),
                "min_opr": float(host[10]),
                "mean_opr": float(host[11]),
                "score": float(host[12]),
                "witness_threshold": float(self.witness_threshold),
                "alpha_opr": float(alpha),
                "gate_mode": str(gate_mode),
                "method": str(method),
                "priority_hard_threshold": float(self.priority_hard_threshold),
                "accepted_primary_bad_candidates": int(host[13]),
                "severe_bad_candidates": int(host[14]),
                "option_bad_candidates": int(host[15]),
                "selected_priority_max": float(host[16]),
                "selected_priority_mean": float(host[17]),
                "selected_outcome_risk": float(host[18]),
                "selected_outcome_decision_risk": float(host[19]),
                "selected_candidate_ncf_prob": float(host[20]),
                "selected_candidate_false_safe_prob": float(host[21]),
                "selected_candidate_quality_prob": float(host[22]),
                "selected_candidate_cert_risk": float(host[23]),
                "selected_candidate_pressure_prior": float(host[24]),
                "selected_candidate_rule_risk": float(host[25]),
                "selected_candidate_action_risk": float(host[26]),
                "min_candidate_cert_risk": float(host[27]),
                "mean_candidate_cert_risk": float(host[28]),
                "mean_candidate_pressure_prior": float(host[29]),
                "mean_candidate_rule_risk": float(host[30]),
                "mean_candidate_action_risk": float(host[31]),
                "beta_threshold": float(self.cfg.get("burden", {}).get("beta0_vehicle", 0.65)),
            }
            if burden is not None:
                diag["max_predicted_burden"] = float(host[32])
            if c_i is not None:
                diag["max_predicted_c_i"] = float(host[33])
        self._last_diagnostics = diag
        self._diagnostics_log.append(diag)
        traj = batch_np["cowp/candidates/trajectory"][0, selected]
        return self._trajectory_to_action(state, agent_state, sdc_index, traj)

    def consume_diagnostics(self) -> dict[str, Any] | None:
        row = self._last_diagnostics
        self._last_diagnostics = None
        return row

    def diagnostics_log(self) -> list[dict[str, Any]]:
        return list(self._diagnostics_log)


def make_cowp_policy(
    checkpoint: str,
    cfg: dict,
    *,
    device: str = "auto",
    witness_threshold: float = 0.5,
    action_mode: str = "delta_xy_yaw",
    ncf_gate_mode: str = "hard",
    priority_hard_threshold: float = 0.55,
    secondary_witness_threshold: float = 0.85,
    secondary_opr_alpha: float = 0.10,
    soft_ncf_penalty: float = 1.5,
    method: str = "cowp",
    adaptive_frontier_margin: float = 0.20,
    outcome_risk_penalty: float = 0.0,
    outcome_risk_threshold: float = 1.10,
) -> COWPWaymaxPolicy:
    return COWPWaymaxPolicy(
        checkpoint=checkpoint,
        cfg=cfg,
        device=device,
        witness_threshold=witness_threshold,
        action_mode=action_mode,
        ncf_gate_mode=ncf_gate_mode,
        priority_hard_threshold=priority_hard_threshold,
        secondary_witness_threshold=secondary_witness_threshold,
        secondary_opr_alpha=secondary_opr_alpha,
        soft_ncf_penalty=soft_ncf_penalty,
        method=method,
        adaptive_frontier_margin=adaptive_frontier_margin,
        outcome_risk_penalty=outcome_risk_penalty,
        outcome_risk_threshold=outcome_risk_threshold,
    )
