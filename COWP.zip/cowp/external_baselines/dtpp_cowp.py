from __future__ import annotations

import math
from typing import Mapping

import torch
import torch.nn as nn
import torch.nn.functional as F


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int = 256, dropout: float = 0.1, max_len: int = 100):
        super().__init__()
        position = torch.arange(max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * (-math.log(10000.0) / d_model))
        pe = torch.zeros(max_len, 1, d_model)
        pe[:, 0, 0::2] = torch.sin(position * div_term)
        pe[:, 0, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.permute(1, 0, 2))
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.dropout(x + self.pe[:, : x.shape[-2]])


class AgentEncoder(nn.Module):
    def __init__(self, agent_dim: int, dim: int = 256):
        super().__init__()
        self.motion = nn.LSTM(agent_dim, dim, 2, batch_first=True)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        traj, _ = self.motion(inputs)
        return traj[:, -1]


class VectorMapEncoder(nn.Module):
    def __init__(self, map_dim: int, map_len: int, dim: int = 256):
        super().__init__()
        self.point_net = nn.Sequential(nn.Linear(map_dim, 64), nn.ReLU(), nn.Linear(64, 128), nn.ReLU(), nn.Linear(128, dim))
        self.position_encode = PositionalEncoding(dim, max_len=map_len)

    def segment_map(self, map_tensor: torch.Tensor, map_encoding: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        B, N_e, N_p, D = map_encoding.shape
        enc = F.max_pool2d(map_encoding.permute(0, 3, 1, 2), kernel_size=(1, 10)).permute(0, 2, 3, 1).reshape(B, -1, D)
        mask = torch.eq(map_tensor, 0)[:, :, :, 0].reshape(B, N_e, N_p // 10, N_p // (N_p // 10))
        mask = torch.max(mask, dim=-1)[0].reshape(B, -1)
        return enc, mask

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        return self.segment_map(x, self.position_encode(self.point_net(x)))


class CrossAttention(nn.Module):
    def __init__(self, heads: int = 8, dim: int = 256, dropout: float = 0.1):
        super().__init__()
        self.cross_attention = nn.MultiheadAttention(dim, heads, dropout, batch_first=True)
        self.norm_1 = nn.LayerNorm(dim)
        self.norm_2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(nn.Linear(dim, dim * 4), nn.GELU(), nn.Dropout(dropout), nn.Linear(dim * 4, dim))
        self.dropout = nn.Dropout(dropout)

    def forward(self, query: torch.Tensor, key: torch.Tensor, value: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        out, _ = self.cross_attention(query, key, value, attn_mask=mask)
        out = self.norm_1(out + query)
        return self.norm_2(out + self.dropout(self.ffn(out)))


class AgentDecoder(nn.Module):
    def __init__(self, max_time: int, max_branch: int, dim: int):
        super().__init__()
        self.max_time = int(max_time)
        self.max_branch = int(max_branch)
        self.traj_decoder = nn.Sequential(nn.Linear(dim, 128), nn.ELU(), nn.Linear(128, 3 * 10))

    def forward(self, encoding: torch.Tensor, current_state: torch.Tensor) -> torch.Tensor:
        encoding = torch.reshape(encoding, (encoding.shape[0], self.max_branch, self.max_time, 512))
        agent_traj = self.traj_decoder(encoding).reshape(encoding.shape[0], self.max_branch, self.max_time * 10, 3)
        agent_traj += current_state[:, None, None, :3]
        return agent_traj


class ScoreDecoder(nn.Module):
    def __init__(self, variable_cost: bool = False):
        super().__init__()
        self.n_latent_features = 4
        self.variable_cost = bool(variable_cost)
        self.interaction_feature_encoder = nn.Sequential(nn.Linear(10, 64), nn.ReLU(), nn.Linear(64, 256))
        self.interaction_feature_decoder = nn.Sequential(nn.Linear(256, 64), nn.ELU(), nn.Linear(64, self.n_latent_features), nn.Sigmoid())
        self.weights_decoder = nn.Sequential(nn.Linear(256, 64), nn.ELU(), nn.Linear(64, self.n_latent_features + 4), nn.Softplus())

    def get_hardcoded_features(self, ego_traj: torch.Tensor, max_time: int) -> torch.Tensor:
        speed = ego_traj[:, :, :max_time, 3]
        acceleration = ego_traj[:, :, :max_time, 4]
        jerk = torch.diff(acceleration, dim=-1) / 0.1
        jerk = torch.cat((jerk[:, :, :1], jerk), dim=-1)
        curvature = ego_traj[:, :, :max_time, 5]
        lateral_acc = speed ** 2 * curvature
        speed = -speed.mean(-1).clip(0, 15) / 15
        acceleration = acceleration.abs().mean(-1).clip(0, 4) / 4
        jerk = jerk.abs().mean(-1).clip(0, 6) / 6
        lateral_acc = lateral_acc.abs().mean(-1).clip(0, 5) / 5
        return torch.stack((speed, acceleration, jerk, lateral_acc), dim=-1)

    def calculate_collision(self, ego_traj: torch.Tensor, agent_traj: torch.Tensor, agents_states: torch.Tensor, max_time: int) -> torch.Tensor:
        agent_mask = torch.ne(agents_states.sum(-1), 0)
        dist = torch.linalg.norm(ego_traj[:, None, :max_time, :2] - agent_traj[:, :, :max_time, :2], dim=-1)
        return (torch.exp(-0.2 * dist ** 2) * agent_mask[:, :, None]).sum(-1).sum(-1)

    def get_latent_interaction_features(self, ego_traj: torch.Tensor, agent_traj: torch.Tensor, agents_states: torch.Tensor, max_time: int) -> torch.Tensor:
        agent_mask = torch.ne(agents_states.sum(-1), 0)
        relative_yaw = torch.atan2(torch.sin(agent_traj[:, :, :max_time, 2] - ego_traj[:, None, :max_time, 2]), torch.cos(agent_traj[:, :, :max_time, 2] - ego_traj[:, None, :max_time, 2]))
        relative_pos = agent_traj[:, :, :max_time, :2] - ego_traj[:, None, :max_time, :2]
        relative_pos = torch.stack([relative_pos[..., 0] * torch.cos(relative_yaw), relative_pos[..., 1] * torch.sin(relative_yaw)], dim=-1)
        agent_velocity = torch.diff(agent_traj[:, :, :max_time, :2], dim=-2) / 0.1
        agent_velocity = torch.cat((agent_velocity[:, :, :1, :], agent_velocity), dim=-2)
        ego_vx = ego_traj[:, :max_time, 3] * torch.cos(ego_traj[:, :max_time, 2])
        ego_vy = ego_traj[:, :max_time, 3] * torch.sin(ego_traj[:, :max_time, 2])
        relative_velocity = torch.stack([(agent_velocity[..., 0] - ego_vx[:, None]) * torch.cos(relative_yaw), (agent_velocity[..., 1] - ego_vy[:, None]) * torch.sin(relative_yaw)], dim=-1)
        relative_attributes = torch.cat((relative_pos, relative_yaw.unsqueeze(-1), relative_velocity), dim=-1)
        agent_attributes = agents_states[:, :, None, 6:].expand(-1, -1, relative_attributes.shape[2], -1)
        attributes = torch.cat((relative_attributes, agent_attributes), dim=-1) * agent_mask[:, :, None, None]
        features = self.interaction_feature_encoder(attributes)
        features = features.max(1).values.mean(1)
        return self.interaction_feature_decoder(features)

    def forward(self, ego_traj: torch.Tensor, ego_encoding: torch.Tensor, agents_traj: torch.Tensor, agents_states: torch.Tensor, timesteps: int) -> tuple[torch.Tensor, torch.Tensor]:
        ego_traj_features = self.get_hardcoded_features(ego_traj, timesteps)
        if not self.variable_cost:
            ego_encoding = torch.ones_like(ego_encoding)
        weights = self.weights_decoder(ego_encoding)
        ego_mask = torch.ne(ego_traj.sum(-1).sum(-1), 0)
        scores = []
        for i in range(agents_traj.shape[1]):
            hard = ego_traj_features[:, i]
            latent = self.get_latent_interaction_features(ego_traj[:, i], agents_traj[:, i], agents_states, timesteps)
            feat = torch.cat((hard, latent), dim=-1)
            score = -torch.sum(feat * weights, dim=-1)
            score += -10.0 * self.calculate_collision(ego_traj[:, i], agents_traj[:, i], agents_states, timesteps)
            scores.append(score)
        scores = torch.stack(scores, dim=1)
        scores = torch.where(ego_mask, scores, torch.full_like(scores, -1e9))
        return scores, weights


class DTPPEncoder(nn.Module):
    def __init__(self, dim: int = 256, layers: int = 3, heads: int = 8, dropout: float = 0.1):
        super().__init__()
        self.agent_encoder = AgentEncoder(11, dim)
        self.ego_encoder = AgentEncoder(7, dim)
        self.lane_encoder = VectorMapEncoder(7, 50, dim)
        self.crosswalk_encoder = VectorMapEncoder(3, 30, dim)
        layer = nn.TransformerEncoderLayer(d_model=dim, nhead=heads, dim_feedforward=dim * 4, activation=F.gelu, dropout=dropout, batch_first=True)
        self.fusion_encoder = nn.TransformerEncoder(layer, layers, enable_nested_tensor=False)

    def forward(self, inputs: Mapping[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        ego = inputs["ego_agent_past"]
        neighbors = inputs["neighbor_agents_past"]
        actors = torch.cat([ego[:, None, :, :5], neighbors[..., :5]], dim=1)
        encoded_ego = self.ego_encoder(ego)
        encoded_neighbors = [self.agent_encoder(neighbors[:, i]) for i in range(neighbors.shape[1])]
        encoded_actors = torch.stack([encoded_ego] + encoded_neighbors, dim=1)
        actors_mask = torch.eq(actors[:, :, -1].sum(-1), 0)
        lanes, lanes_mask = self.lane_encoder(inputs["map_lanes"])
        cross, cross_mask = self.crosswalk_encoder(inputs["map_crosswalks"])
        inp = torch.cat([encoded_actors, lanes, cross], dim=1)
        mask = torch.cat([actors_mask, lanes_mask, cross_mask], dim=1)
        return {"encoding": self.fusion_encoder(inp, src_key_padding_mask=mask), "mask": mask}


class DTPPDecoder(nn.Module):
    def __init__(self, neighbors: int = 10, max_time: int = 8, max_branch: int = 30, n_heads: int = 8, dim: int = 256, variable_cost: bool = False):
        super().__init__()
        self.neighbors = int(neighbors)
        self.nheads = int(n_heads)
        self.time = int(max_time)
        self.branch = int(max_branch)
        self.environment_decoder = CrossAttention(n_heads, dim)
        self.ego_condition_decoder = CrossAttention(n_heads, dim)
        self.time_embed = nn.Embedding(max_time, dim)
        self.ego_traj_encoder = nn.Sequential(nn.Linear(6, 64), nn.ReLU(), nn.Linear(64, dim))
        self.agent_traj_decoder = AgentDecoder(max_time, max_branch, dim * 2)
        self.ego_traj_decoder = nn.Sequential(nn.Linear(dim, dim), nn.ELU(), nn.Linear(dim, max_time * 10 * 3))
        self.scorer = ScoreDecoder(variable_cost)
        self.register_buffer("casual_mask", self.generate_casual_mask())
        self.register_buffer("time_index", torch.arange(max_time).repeat(max_branch, 1))

    def pooling_trajectory(self, trajectory_tree: torch.Tensor) -> torch.Tensor:
        B, M, T, D = trajectory_tree.shape
        if T < 10:
            return torch.max(trajectory_tree, dim=2, keepdim=True).values
        pad = (-T) % 10
        if pad:
            trajectory_tree = F.pad(trajectory_tree, (0, 0, 0, pad))
            T = T + pad
        trajectory_tree = torch.reshape(trajectory_tree, (B, M, T // 10, 10, D))
        return torch.max(trajectory_tree, dim=-2)[0]

    def generate_casual_mask(self) -> torch.Tensor:
        time_mask = torch.tril(torch.ones(self.time, self.time))
        mask = torch.zeros(self.branch * self.time, self.branch * self.time)
        for i in range(self.branch):
            mask[i * self.time : (i + 1) * self.time, i * self.time : (i + 1) * self.time] = time_mask
        return mask

    def forward(self, encoder_outputs: Mapping[str, torch.Tensor], ego_traj_inputs: torch.Tensor, agents_states: torch.Tensor, timesteps: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        current_states = agents_states[:, : self.neighbors, -1]
        encoding, encoding_mask = encoder_outputs["encoding"], encoder_outputs["mask"]
        ego_traj_ori_encoding = self.ego_traj_encoder(ego_traj_inputs)
        branch_t = min(max(int(timesteps), 1), ego_traj_ori_encoding.shape[2]) - 1
        branch_embedding = ego_traj_ori_encoding[:, :, branch_t]
        time_embedding = self.time_embed(self.time_index)
        tree_embedding = time_embedding[None] + branch_embedding[:, :, None, :]
        raw_ego_traj_mask = torch.ne(ego_traj_inputs.sum(-1), 0)
        step = max(raw_ego_traj_mask.shape[-1] // self.time, 1)
        ego_traj_mask_3d = raw_ego_traj_mask[:, :, ::step][:, :, : self.time]
        ego_tree_for_attn = ego_traj_ori_encoding[:, :, ::step][:, :, : self.time]
        if ego_traj_mask_3d.shape[2] < self.time:
            pad_t = self.time - ego_traj_mask_3d.shape[2]
            ego_traj_mask_3d = F.pad(ego_traj_mask_3d, (0, pad_t), value=False)
            ego_tree_for_attn = F.pad(ego_tree_for_attn, (0, 0, 0, pad_t), value=0.0)
        ego_traj_mask = torch.reshape(ego_traj_mask_3d, (ego_traj_mask_3d.shape[0], -1)).bool()
        # MultiheadAttention returns NaNs when a query row has every key masked.
        # Padded/invalid candidate branches are later removed by candidate_valid,
        # so let those query rows attend normally and mask only valid query rows.
        env_allowed = ego_traj_mask[:, :, None] & encoding_mask.logical_not()[:, None, :]
        env_mask = torch.where(env_allowed, 0.0, -1e9)
        env_mask = torch.where(ego_traj_mask[:, :, None], env_mask, torch.zeros_like(env_mask))
        env_mask = env_mask.repeat(self.nheads, 1, 1)
        causal = self.casual_mask.to(device=ego_traj_inputs.device, dtype=torch.bool)[None]
        ego_key_valid = ego_traj_mask[:, None, :]
        ego_allowed = ego_traj_mask[:, :, None] & ego_key_valid & causal
        ego_condition_mask = torch.where(ego_allowed, 0.0, -1e9)
        ego_condition_mask = torch.where(ego_traj_mask[:, :, None], ego_condition_mask, torch.zeros_like(ego_condition_mask))
        ego_condition_mask = ego_condition_mask.repeat(self.nheads, 1, 1)
        ego_flat = torch.reshape(ego_tree_for_attn, (ego_tree_for_attn.shape[0], -1, ego_tree_for_attn.shape[-1]))
        agents_trajectories = []
        for i in range(self.neighbors):
            query = encoding[:, i + 1, None, None] + tree_embedding
            query = torch.reshape(query, (query.shape[0], -1, query.shape[-1]))
            env_dec = self.environment_decoder(query, encoding, encoding, env_mask)
            ego_dec = self.ego_condition_decoder(query, ego_flat, ego_flat, ego_condition_mask)
            dec = torch.cat([env_dec, ego_dec], dim=-1)
            agents_trajectories.append(self.agent_traj_decoder(dec, current_states[:, i]))
        agents_trajectories = torch.stack(agents_trajectories, dim=2)
        scores, weights = self.scorer(ego_traj_inputs, encoding[:, 0], agents_trajectories, current_states, timesteps)
        ego_reg = self.ego_traj_decoder(encoding[:, 0]).reshape(encoding.shape[0], self.time * 10, 3)
        return agents_trajectories, scores, ego_reg, weights


class COWPDTPP(nn.Module):
    def __init__(self, neighbors: int = 10, max_branch: int = 30, variable_cost: bool = True):
        super().__init__()
        self.neighbors = int(neighbors)
        self.max_branch = int(max_branch)
        self.encoder = DTPPEncoder()
        self.decoder = DTPPDecoder(neighbors=neighbors, max_branch=max_branch, variable_cost=variable_cost)

    def forward(self, inputs: Mapping[str, torch.Tensor], ego_traj_tree: torch.Tensor, timesteps: int = 80) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        enc = self.encoder(inputs)
        return self.decoder(enc, ego_traj_tree, inputs["neighbor_agents_past"], timesteps)

    def score_candidates(self, inputs: Mapping[str, torch.Tensor], ego_traj_tree: torch.Tensor, candidate_valid: torch.Tensor, timesteps: int = 80) -> torch.Tensor:
        _, scores, _, _ = self.forward(inputs, ego_traj_tree, timesteps=timesteps)
        return torch.where(candidate_valid, scores, torch.full_like(scores, -1e9))


def dtpp_loss(model: COWPDTPP, inputs: Mapping[str, torch.Tensor], ego_traj_tree: torch.Tensor, candidate_valid: torch.Tensor, best_idx: torch.Tensor, ego_future_xy: torch.Tensor, ego_future_valid: torch.Tensor, neighbors_future_xy: torch.Tensor, neighbors_future_valid: torch.Tensor, timesteps: int = 80) -> tuple[torch.Tensor, dict[str, float]]:
    neighbors_pred, scores, ego_reg, weights = model(inputs, ego_traj_tree, timesteps=timesteps)
    B = scores.shape[0]
    scores_masked = torch.where(candidate_valid, scores, torch.full_like(scores, -1e9))
    ce = F.cross_entropy(scores_masked, best_idx.long())
    row = torch.arange(B, device=scores.device)
    pred = neighbors_pred[row, best_idx]
    T = min(pred.shape[2], neighbors_future_xy.shape[2])
    pred_xy = pred[:, :, :T, :2]
    gt_xy = neighbors_future_xy[:, :, :T, :2]
    valid = neighbors_future_valid[:, :, :T].float()
    cmp_loss = F.smooth_l1_loss(pred_xy, gt_xy, reduction="none").sum(-1)
    cmp_loss = (cmp_loss * valid).sum() / valid.sum().clamp_min(1.0)
    ego_T = min(ego_reg.shape[1], ego_future_xy.shape[1])
    reg = F.smooth_l1_loss(ego_reg[:, :ego_T, :2], ego_future_xy[:, :ego_T], reduction="none").sum(-1)
    reg = (reg * ego_future_valid[:, :ego_T].float()).sum() / ego_future_valid[:, :ego_T].float().sum().clamp_min(1.0)
    wreg = torch.square(weights).mean()
    loss = ce + cmp_loss + 0.1 * reg + 0.01 * wreg
    sel = torch.argmax(scores_masked, dim=1)
    plan = ego_traj_tree[row, sel, :, :2]
    pt = min(plan.shape[1], ego_future_xy.shape[1])
    pde = torch.linalg.norm((plan[:, :pt] - ego_future_xy[:, :pt]) * ego_future_valid[:, :pt, None].float(), dim=-1)
    metrics = {"plannerADE": float((pde.sum() / ego_future_valid[:, :pt].float().sum().clamp_min(1.0)).detach().cpu())}
    return loss, metrics
