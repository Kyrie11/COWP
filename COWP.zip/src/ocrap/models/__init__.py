from .ocrap import OCRAPModel
